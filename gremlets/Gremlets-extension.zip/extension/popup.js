// Popup: bring Gremlets to the current tab, keep them on a site, and tune them.
const $ = (id) => document.getElementById(id);

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let url = null;
  try { url = new URL(tab.url); } catch { /* chrome:// pages etc. */ }
  const web = url && /^https?:$/.test(url.protocol);
  const origin = web ? `${url.protocol}//${url.host}/*` : null;
  const scriptId = web ? 'gremlets-' + url.host.replace(/[^a-z0-9.-]/gi, '_') : null;
  const gardenKey = web ? 'garden:' + url.host + url.pathname : null;

  if (!web) {
    $('go').disabled = true; $('always').disabled = true;
    $('msg').textContent = "Browsers don't let extensions add anything to this kind of page. Try a regular website.";
  } else {
    $('host').textContent = url.host;
  }

  // Settings.
  const { settings = {} } = await chrome.storage.local.get('settings');
  const s = { count: 3, nibble: true, ...settings };
  $('count').value = s.count; $('countLabel').textContent = s.count; $('nibble').checked = s.nibble;
  const save = () => chrome.storage.local.set({ settings: { count: +$('count').value, nibble: $('nibble').checked } });
  $('count').addEventListener('input', () => { $('countLabel').textContent = $('count').value; save(); });
  $('nibble').addEventListener('change', save);

  // Garden.
  const showGarden = async () => {
    if (!gardenKey) return;
    const r = await chrome.storage.local.get(gardenKey);
    $('flowers').textContent = (r[gardenKey] || []).length;
  };
  showGarden();
  $('clear').addEventListener('click', async () => { if (gardenKey) { await chrome.storage.local.remove(gardenKey); showGarden(); } });

  // Bring them here (activeTab lets us add to this tab once, without asking for any site access).
  $('go').addEventListener('click', async () => {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['js/content.js'] });
      window.close();
    } catch (e) {
      $('msg').textContent = "Couldn't add Gremlets to this page. Some pages block extensions.";
    }
  });

  // Always on this site: ask for access to just this site, then register the script for it.
  if (web) {
    const has = await chrome.permissions.contains({ origins: [origin] });
    const regs = await chrome.scripting.getRegisteredContentScripts({ ids: [scriptId] }).catch(() => []);
    $('always').checked = has && regs.length > 0;
  }
  $('always').addEventListener('change', async (e) => {
    if (e.target.checked) {
      const ok = await chrome.permissions.request({ origins: [origin] });
      if (!ok) { e.target.checked = false; return; }
      const regs = await chrome.scripting.getRegisteredContentScripts({ ids: [scriptId] }).catch(() => []);
      if (!regs.length) await chrome.scripting.registerContentScripts([{ id: scriptId, matches: [origin], js: ['js/content.js'], runAt: 'document_idle', persistAcrossSessions: true }]);
    } else {
      await chrome.scripting.unregisterContentScripts({ ids: [scriptId] }).catch(() => {});
      await chrome.permissions.remove({ origins: [origin] }).catch(() => {});
    }
  });
})();
