// Injected into a page when you click "Bring Gremlets here" (or automatically on sites you've allowed).
// Loads the overlay as a module so it can share the engine with the web habitat.
(() => {
  if (window.__gremletsLoading) { window.__gremlets?.toggle?.(); return; }
  window.__gremletsLoading = true;
  import(chrome.runtime.getURL('js/overlay.js')).then((m) => m.start()).catch((err) => console.warn('Gremlets could not start:', err));
})();
