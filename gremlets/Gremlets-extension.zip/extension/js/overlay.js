// Gremlets on any web page: the same engine as the Mac app and the web habitat, with the page's own headings,
// paragraphs, images and buttons as the platforms. Nothing on the page is changed: nibbled letters and gardens are
// drawn on a transparent layer on top, and gardens are saved in this browser only (chrome.storage.local).
import { World, Species, V } from './engine.js';
import { FX, Particles } from './effects.js';

const BASE = chrome.runtime.getURL('Species/');
const FAVORITES = ['kindlet', 'dandelet', 'flurrie', 'capyzen', 'lilypip', 'puffcloud', 'bubbit', 'calicat', 'shibun', 'mossfawn',
  'rustle', 'seedcheek', 'gumleaf', 'marimoss', 'puffcap', 'pomble', 'alpocco', 'swirlby'];
const PX = 2;
const SEL = 'h1,h2,h3,h4,h5,p,li,img,picture,video,button,input,textarea,select,pre,blockquote,table,figure,iframe,label,summary,[role=button],[role=img]';
const TEXTY = new Set(['H1', 'H2', 'H3', 'H4', 'H5', 'P', 'LI', 'BUTTON', 'LABEL', 'SUMMARY', 'BLOCKQUOTE']);
const GARDEN_KEY = 'garden:' + location.host + location.pathname;
const MAX_FLOWERS = 24;

const world = new World();
const particles = new Particles();
const art = new Map();
const elById = new Map();
const ids = new WeakMap();
let nextElId = 1;
let root, canvas, ctx, bubbleHost, hint;
let W = 0, H = 0, DPR = 1;
let running = false, raf = 0, scanTimer = 0, chores = 0;
let settings = { count: 3, nibble: true };
let garden = [];          // { sel, fx, kind, t }
const bites = [];         // { id, dx, dy, w, h, color }
let driven = null;
const keys = { left: false, right: false, up: false };
const mined = new WeakSet();   // elements a Gremlet has mined away (only drawn over; a reload brings them back)
const cracks = new Map();      // element id -> hits so far
const holes = [];              // { el, color }
const debris = [];             // pixel chips flying off mined blocks
const swings = [];             // { id, t0 }
const bubbles = [];

const store = {
  async get(k, d) { try { const r = await chrome.storage.local.get(k); return r[k] ?? d; } catch { return d; } },
  async set(k, v) { try { await chrome.storage.local.set({ [k]: v }); } catch { /* storage unavailable */ } },
};

// ---------------------------------------------------------------- sprites (fetched as blobs so masks can be read)

const cache = new Map();
function loadSpecies(id) {
  if (cache.has(id)) return cache.get(id);
  const p = (async () => {
    const [sheet, info, blob] = await Promise.all([
      fetch(`${BASE}${id}/sheet.json`).then((r) => r.json()),
      fetch(`${BASE}${id}/species.json`).then((r) => r.json()).catch(() => ({})),
      fetch(`${BASE}${id}/sheet.png`).then((r) => r.blob()),
    ]);
    const image = await createImageBitmap(blob);
    const frames = Array.isArray(sheet.frames) ? sheet.frames : Object.values(sheet.frames);
    const rects = frames.map((f) => f.frame);
    const durations = frames.map((f) => (f.duration ?? 100) / 1000);
    const cv = new OffscreenCanvas(image.width, image.height);
    const g = cv.getContext('2d', { willReadFrequently: true });
    g.drawImage(image, 0, 0);
    const masks = rects.map((r) => {
      const d = g.getImageData(r.x, r.y, r.w, r.h).data;
      const m = new Array(r.w * r.h);
      for (let i = 0; i < m.length; i++) m[i] = d[i * 4 + 3] > 24;
      return m;
    });
    const animations = {};
    for (const tag of sheet.meta?.frameTags ?? []) {
      const idx = [];
      for (let i = tag.from; i <= tag.to; i++) idx.push(i);
      animations[tag.name.toLowerCase()] = { frames: idx, durations: idx.map((i) => durations[i]) };
    }
    const species = new Species({
      id, name: info.name ?? id, frameWidth: Math.max(...rects.map((r) => r.w)), frameHeight: Math.max(...rects.map((r) => r.h)),
      scale: PX, animations, masks, walkSpeed: (info.walkSpeed ?? 70) * 0.75, jumpPower: (info.jumpPower ?? 1) * 0.8,
      sleepiness: info.sleepiness ?? 1, flies: !!info.flies, special: info.special ?? 'sparkle',
    });
    return { species, image, rects };
  })();
  cache.set(id, p);
  return p;
}

// ---------------------------------------------------------------- page → platforms

const toScreen = (x, y) => ({ x, y: H - y });
const toWorld = (e) => V(e.clientX, H - e.clientY);

function scan() {
  if (!running) return;
  W = document.documentElement.clientWidth || innerWidth; H = innerHeight;
  elById.clear();
  const wins = [];
  for (const el of document.querySelectorAll(SEL)) {
    if (root.contains(el) || mined.has(el)) continue;
    const r = el.getBoundingClientRect();
    if (r.width < 48 || r.height < 12 || r.bottom <= 0 || r.top >= H || r.top < 48 || r.right <= 0 || r.left >= W) continue;
    if (el.checkVisibility && !el.checkVisibility({ opacityProperty: true, visibilityProperty: true })) continue;
    let id = ids.get(el);
    if (!id) { id = nextElId++; ids.set(el, id); }
    elById.set(id, el);
    wins.push({ id, x: r.left, y: H - r.bottom, w: r.width, h: r.height });
    if (wins.length >= 160) break;
  }
  // Later in the page draws on top, so it goes first.
  world.setEnvironment([{ x: 0, y: 0, w: W, h: H }], wins.reverse());
}

function resize() {
  DPR = Math.min(devicePixelRatio || 1, 3);
  W = document.documentElement.clientWidth || innerWidth; H = innerHeight;
  canvas.width = Math.round(W * DPR); canvas.height = Math.round(H * DPR);
  canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
  scan();
}

// ---------------------------------------------------------------- creatures

async function addGremlet(id, x) {
  const a = await loadSpecies(id);
  const c = world.spawn(a.species, V(x ?? W * (0.1 + Math.random() * 0.8), H - 60 - Math.random() * 80));
  art.set(c.id, a);
  return c;
}

function syncCount() {
  const want = Math.max(1, Math.min(8, settings.count | 0));
  while (world.creatures.length > want) { const c = world.creatures[world.creatures.length - 1]; if (c.id === driven) driven = null; world.remove(c.id); art.delete(c.id); }
  const have = new Set(world.creatures.map((c) => c.species.id));
  const pool = FAVORITES.filter((id) => !have.has(id)).sort(() => Math.random() - 0.5);
  for (let i = world.creatures.length; i < want; i++) addGremlet(pool[i % pool.length]);
}

// ---------------------------------------------------------------- nibbling (drawn over the page; nothing is edited)

function backgroundOf(el) {
  for (let e = el; e; e = e.parentElement) {
    const c = getComputedStyle(e).backgroundColor;
    if (c && c !== 'transparent' && !/rgba\([^)]*,\s*0\)$/.test(c)) return c;
  }
  return getComputedStyle(document.documentElement).backgroundColor || '#fff';
}

function nibble() {
  if (!settings.nibble || bites.length > 60) return;
  const cands = world.creatures.filter((c) => c.isGrounded && c.ground > 0 && c.id !== driven && ['idle', 'walk'].includes(c.activity));
  if (!cands.length) return;
  const c = cands[Math.floor(Math.random() * cands.length)];
  const el = elById.get(c.ground);
  if (!el || !TEXTY.has(el.tagName) || el.isContentEditable || el.closest('[contenteditable=""],[contenteditable=true],input,textarea')) return;
  const r = el.getBoundingClientRect();
  const sx = c.pos.x + c.facing * c.size.x * 0.45, sy = r.top + 6;
  canvas.classList.remove('live');
  const range = document.caretRangeFromPoint?.(sx, sy);
  if (!range || range.startContainer.nodeType !== 3 || !el.contains(range.startContainer)) return;
  const node = range.startContainer, i = range.startOffset;
  if (!node.data[i] || /\s/.test(node.data[i])) return;
  range.setStart(node, i); range.setEnd(node, i + 1);
  const cr = range.getBoundingClientRect();
  if (!cr.width || Math.abs(cr.left + cr.width / 2 - sx) > 30 || cr.top > r.top + 30) return;
  bites.push({ id: c.ground, dx: cr.left - r.left - 1, dy: cr.top - r.top, w: cr.width + 2, h: cr.height, color: backgroundOf(el), t: performance.now() / 1000 });
  c.facing = cr.left + cr.width / 2 > c.pos.x ? 1 : -1;
  c.set('react', c.animationLength('react') + 0.1);
  particles.burst(FX.seed, V(cr.left + cr.width / 2, H - cr.top - cr.height / 2), { count: 4, dx: [-14, 14], dy: [-22, 6], duration: 0.6, stagger: 0.05 });
  if (Math.random() < 0.35) say(c.id, ['nom', 'crunchy!', 'tasty letter', 'mmm, an ' + node.data[i]][Math.floor(Math.random() * 4)], 1.6);
}

// ---------------------------------------------------------------- gardens that stay on the page

function cssPath(el) {
  const parts = [];
  for (let e = el; e && e.nodeType === 1 && e !== document.body; e = e.parentElement) {
    if (e.id && /^[A-Za-z][\w-]*$/.test(e.id)) { parts.unshift('#' + e.id); return parts.join('>'); }
    let i = 1, s = e;
    while ((s = s.previousElementSibling)) if (s.tagName === e.tagName) i++;
    parts.unshift(`${e.tagName.toLowerCase()}:nth-of-type(${i})`);
  }
  return 'body>' + parts.join('>');
}

const FLOWERS = {
  tulip: { rows: ['.r.r.', 'rrrrr', '.rRr.', '..g..', 'gg.gg', '.ggg.', '..g..'], pal: { r: '#ff6f7e', R: '#d8455a', g: '#5aa54e' } },
  daisy: { rows: ['.w.w.', 'wwyww', '.wyw.', 'w.g.w', '..g..', '.gg..', '..g..'], pal: { w: '#ffffff', y: '#ffd84a', g: '#5aa54e' } },
  bell: { rows: ['..g..', '.gBg.', '.BBB.', 'B.g.B', '..g..', 'gg.g.', '..g..'], pal: { B: '#6f8ff0', g: '#5aa54e' } },
  sun: { rows: ['y.y.y', '.yby.', 'ybbby', '.yby.', 'y.g.y', '..gg.', '..g..'], pal: { y: '#ffd84a', b: '#7a4e2a', g: '#5aa54e' } },
  lav: { rows: ['.v.v.', 'vVvVv', '.v.v.', '.vgv.', '..g..', '.gg..', '..g..'], pal: { v: '#a98bea', V: '#7a5fc9', g: '#5aa54e' } },
};
const KINDS = Object.keys(FLOWERS);
const anchors = new Map();   // sel -> element (cached)

function anchor(sel) {
  if (anchors.has(sel)) { const el = anchors.get(sel); if (el?.isConnected) return el; }
  let el = null;
  try { el = document.querySelector(sel); } catch { /* bad selector */ }
  anchors.set(sel, el);
  return el;
}

function plant() {
  if (garden.length >= MAX_FLOWERS) return;
  const cands = world.creatures.filter((c) => c.isGrounded && c.ground > 0 && c.activity === 'idle' && c.id !== driven);
  if (!cands.length) return;
  const c = cands[Math.floor(Math.random() * cands.length)];
  const el = elById.get(c.ground);
  if (!el) return;
  const r = el.getBoundingClientRect();
  const x = c.pos.x + c.facing * 16, fx = (x - r.left) / r.width;
  if (fx < 0.02 || fx > 0.98) return;
  const sel = cssPath(el);
  if (garden.some((f) => f.sel === sel && Math.abs(f.fx - fx) * r.width < 22)) return;
  garden.push({ sel, fx: +fx.toFixed(4), kind: KINDS[Math.floor(Math.random() * KINDS.length)], t: Date.now() });
  store.set(GARDEN_KEY, garden);
  c.idleVariant = 'crouch'; c.set('idle', 1.4);
  particles.burst(FX.dust, V(x, c.pos.y + 3), { count: 3, dx: [-12, 12], dy: [0, 6], duration: 0.45, spin: 0 });
  if (Math.random() < 0.5) say(c.id, 'planted something 🌱', 2);
}

function drawGarden(now) {
  for (const f of garden) {
    const el = anchor(f.sel);
    if (!el) continue;
    const r = el.getBoundingClientRect();
    if (r.bottom < 0 || r.top > H || r.width < 1) continue;
    const fl = FLOWERS[f.kind] || FLOWERS.tulip;
    const grow = Math.min(1, (Date.now() - f.t) / 2500);
    const rows = fl.rows.slice(Math.floor((1 - grow) * (fl.rows.length - 2)));
    const x = r.left + f.fx * r.width - 5 * PX / 2, top = r.top - rows.length * PX;
    rows.forEach((row, y) => [...row].forEach((ch, xx) => {
      const col = fl.pal[ch];
      if (!col) return;
      ctx.fillStyle = col; ctx.fillRect(Math.round(x + xx * PX), Math.round(top + y * PX), PX, PX);
    }));
  }
}

// ---------------------------------------------------------------- input

let press = null, lastHover = null, lastTap = null;

function hoverCheck(e) {
  if (!running) return;
  const p = toWorld(e);
  if (e.pointerType === 'mouse' || press) world.cursor = p;
  if (press) return;
  const c = world.creatureAt(p);
  canvas.classList.toggle('live', !!c);
  if (c && lastHover) world.pet(c, Math.hypot(p.x - lastHover.x, p.y - lastHover.y));
  lastHover = c ? p : null;
}

function wireInput() {
  addEventListener('pointermove', hoverCheck, true);
  canvas.addEventListener('pointerdown', (e) => {
    const p = toWorld(e), c = world.creatureAt(p);
    if (!c) { canvas.classList.remove('live'); return; }
    e.preventDefault(); e.stopPropagation();
    const now = performance.now();
    if (lastTap && lastTap.id === c.id && now - lastTap.t < 320) { lastTap = null; takeControl(c); return; }
    lastTap = { id: c.id, t: now };
    try { canvas.setPointerCapture(e.pointerId); } catch { /* ignore */ }
    press = { c, start: p, dragging: false };
  });
  canvas.addEventListener('pointermove', (e) => {
    if (!press) return;
    const p = toWorld(e), t = performance.now() / 1000;
    if (!press.dragging && Math.hypot(p.x - press.start.x, p.y - press.start.y) > 6) { press.dragging = true; world.beginDrag(press.c, press.start, t); canvas.classList.add('grab'); }
    if (press.dragging) world.drag(press.c, p, t);
  });
  const up = (e) => {
    if (!press) return;
    const t = performance.now() / 1000;
    if (press.dragging) { world.drag(press.c, toWorld(e), t); world.endDrag(press.c, t); }
    else world.poke(press.c);
    press = null; canvas.classList.remove('grab');
  };
  canvas.addEventListener('pointerup', up);
  canvas.addEventListener('pointercancel', up);
  addEventListener('keydown', onKey, true);
  addEventListener('keyup', (e) => {
    const k = e.key.toLowerCase();
    if (k === 'arrowleft' || k === 'a') keys.left = false;
    if (k === 'arrowright' || k === 'd') keys.right = false;
    if (k === 'arrowup' || k === 'w' || k === ' ') keys.up = false;
  }, true);
  addEventListener('scroll', () => { cancelAnimationFrame(scanTimer); scanTimer = requestAnimationFrame(scan); }, { passive: true, capture: true });
  addEventListener('resize', resize);
}

function onKey(e) {
  if (driven == null) return;
  const typing = e.target?.closest?.('input,textarea,select,[contenteditable=""],[contenteditable=true]');
  if (typing) return;
  const k = e.key.toLowerCase();
  const stop = () => { e.preventDefault(); e.stopPropagation(); };
  if (k === 'escape') { takeControl(null); stop(); }
  else if (k === 'arrowleft' || k === 'a') { keys.left = true; stop(); }
  else if (k === 'arrowright' || k === 'd') { keys.right = true; stop(); }
  else if (k === 'arrowup' || k === 'w' || k === ' ') { if (!e.repeat) { keys.up = true; jump(); } stop(); }
  else if ((k === 'x' || k === 'j') && !e.repeat) { swing(); stop(); }
  else if (k === 'arrowdown' || k === 's') stop();
  else if (k === 'e' && !e.repeat) { const c = world.byId(driven); if (c?.isGrounded) c.set('wave', 1.3); stop(); }
  else if (k === 'q' && !e.repeat) { const c = world.byId(driven); if (c?.isGrounded) world.startSpecial(c); stop(); }
}

function takeControl(c) {
  const old = world.byId(driven);
  if (old) old.speedBoost = 1;
  driven = c && driven !== c.id ? c.id : null;
  keys.left = keys.right = keys.up = false;
  const d = world.byId(driven);
  if (d) say(d.id, 'You drive! 🎮', 1.6);
  hint.hidden = !d;
  if (d) hint.textContent = `Driving ${d.species.name} · ← → walk · Space jump (hold to fly) · X mine · E wave · Q special · Esc let go`;
}

function jump() {
  const c = world.byId(driven);
  if (!c?.isGrounded) return;
  c.jumpAt = performance.now() / 1000;
  const moving = keys.left || keys.right;
  world.launch(c, V(moving ? c.facing * c.species.walkSpeed * 2.8 : c.facing * 20, Math.sqrt(2 * world.gravity * 150 * (c.species.jumpPower || 1))));
}

function steer(dt) {
  const c = world.byId(driven);
  if (!c) { if (driven != null) takeControl(null); return; }
  c.speedBoost = 2.4;
  boots(c, dt);
  const dir = (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
  if (c.activity === 'airborne') { if (dir) c.vel = V(c.vel.x + (dir * c.species.walkSpeed * 2.8 - c.vel.x) * Math.min(1, dt * 5), c.vel.y); return; }
  if (!c.isGrounded) return;
  if (dir) { c.facing = dir; c.edgeDecided = true; if (c.activity !== 'walk') c.set('walk', 0.3); else c.timer = 0.3; return; }
  if (c.activity === 'walk') { c.idleVariant = 'idle'; c.set('idle', 0.4); return; }
  if (c.activity === 'idle') { c.timer = Math.max(c.timer, 0.3); return; }
  if (c.timer < 0.05 && !['crouch', 'sleep', 'yawn', 'wake'].includes(c.activity)) { c.idleVariant = 'idle'; c.set('idle', 0.4); }
}

// ---------------------------------------------------------------- mining (⛏ X) and rocket boots (hold jump)

function swing() {
  const c = world.byId(driven);
  if (!c) return;
  const t = performance.now() / 1000;
  if (c.swingAt && t - c.swingAt < 0.3) return;
  c.swingAt = t;
  swings.push({ id: c.id, t0: t });
  const f = c.facing, w = c.size.x, h = c.size.y;
  const box = { x0: f > 0 ? c.pos.x - w * 0.1 : c.pos.x - w * 0.95, x1: f > 0 ? c.pos.x + w * 0.95 : c.pos.x + w * 0.1, y0: c.pos.y - 14, y1: c.pos.y + h * 0.9 };
  // Bonk any Gremlet in reach.
  for (const o of world.creatures) {
    if (o === c || o.activity === 'dragged') continue;
    const b = o.bounds;
    if (b.x + b.w < box.x0 || b.x > box.x1 || b.y + b.h < box.y0 || b.y > box.y1) continue;
    world.endSocial(o); o.ground = null; o.vel = V(f * 240, 320); o.facing = -f; o.set('airborne');
    particles.burst(FX.smallStar, V(o.pos.x, o.pos.y + o.size.y * 0.8), { count: 3, dx: [-20, 20], dy: [8, 26], duration: 0.6 });
  }
  // Mine the block in front, or the one underfoot.
  let id = null;
  for (const [eid, el] of elById) {
    const r = el.getBoundingClientRect(), y0 = H - r.bottom, y1 = H - r.top;
    if (r.right > box.x0 && r.left < box.x1 && y1 > box.y0 && y0 < box.y1) { id = eid; if (eid === c.ground) break; }
  }
  if (id == null && c.ground > 0) id = c.ground;
  const el = elById.get(id);
  if (!el) return;
  const r = el.getBoundingClientRect();
  const hx = Math.max(r.left + 4, Math.min(r.right - 4, c.pos.x + f * w * 0.6));
  const hits = (cracks.get(id) || 0) + 1;
  cracks.set(id, hits);
  const media = /^(IMG|PICTURE|VIDEO|FIGURE|IFRAME)$/.test(el.tagName);
  const colors = media ? ['#c9cfd6', '#9aa0a6', '#e8e2d0', '#7a8088'] : [backgroundOf(el), getComputedStyle(el).color || '#333', '#c9cfd6'];
  chipsAt(hx, H - r.top, colors, 5);
  if (hits < 3) return;
  if (r.width * r.height > W * H * 0.25) { cracks.set(id, 2); say(c.id, 'Too big to mine!', 1.4); return; }
  mined.add(el); cracks.delete(id);
  holes.push({ el, color: el.parentElement ? backgroundOf(el.parentElement) : '#fff' });
  for (let x = r.left; x < r.right; x += 14) chipsAt(x, H - r.top - r.height / 2, colors, 2);
  scan();
  if (Math.random() < 0.6) say(c.id, ['Mined it! ⛏', 'Block get!', 'Timber!'][Math.floor(Math.random() * 3)], 1.5);
}

function chipsAt(x, y, colors, n) {
  for (let i = 0; i < n; i++) debris.push({ x, y, vx: (Math.random() - 0.5) * 320, vy: 160 + Math.random() * 260, color: colors[i % colors.length], t: 0, life: 0.8 + Math.random() * 0.5 });
}

function boots(c, dt) {
  const t = performance.now() / 1000;
  c.boosting = !!(c.activity === 'airborne' && keys.up && (c.fuel ?? 1) > 0 && t > (c.jumpAt || 0) + 0.18);
  if (c.boosting) {
    c.fuel = Math.max(0, (c.fuel ?? 1) - dt * 0.5);
    c.vel = V(c.vel.x, Math.min(c.vel.y + 2500 * dt, 380));
    c.bootT = (c.bootT || 0) - dt;
    if (c.bootT <= 0) { c.bootT = 0.04; particles.burst(null, V(c.pos.x, c.pos.y + 2), { imgs: [FX.flame2, FX.sparkle], dx: [-8, 8], dy: [-36, -20], duration: 0.3, spin: 0 }); }
  } else if (c.isGrounded) c.fuel = Math.min(1, (c.fuel ?? 1) + dt * 0.9);
}

const PICK = ['.ggggggg.', 'gGGGGGGGg', 'g...h...g', '....h....', '....h....', '....h....', '....h....', '....h....', '....h....'];
const PICK_COLORS = { g: '#5b616b', G: '#c9cfd6', h: '#8a5a34' };

function drawMining(t, dt) {
  for (const hole of holes) {
    if (!hole.el.isConnected) continue;
    const r = hole.el.getBoundingClientRect();
    if (r.bottom < 0 || r.top > H) continue;
    ctx.fillStyle = hole.color; ctx.fillRect(Math.floor(r.left) - 1, Math.floor(r.top) - 1, Math.ceil(r.width) + 2, Math.ceil(r.height) + 2);
  }
  ctx.fillStyle = 'rgba(30,20,20,0.7)';
  for (const [id, n] of cracks) {
    const el = elById.get(id);
    if (!el) continue;
    const r = el.getBoundingClientRect();
    let seed = id * 9301;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    for (let i = 0; i < n * 4; i++) {
      let x = r.left + 4 + Math.floor(rnd() * (r.width - 8) / 2) * 2, y = r.top;
      for (let k = 0; k < 4; k++) { ctx.fillRect(x, y, 2, 2); x += rnd() < 0.5 ? -2 : 2; y += 2; }
    }
  }
  for (let i = debris.length - 1; i >= 0; i--) {
    const d = debris[i];
    d.t += dt; d.vy -= 1400 * dt; d.x += d.vx * dt; d.y += d.vy * dt;
    if (d.t > d.life || d.y < -20) { debris.splice(i, 1); continue; }
    ctx.globalAlpha = Math.min(1, (d.life - d.t) * 3);
    ctx.fillStyle = d.color; ctx.fillRect(Math.round(d.x), Math.round(H - d.y), PX + 1, PX + 1);
  }
  ctx.globalAlpha = 1;
  for (let i = swings.length - 1; i >= 0; i--) {
    const sw = swings[i], c = world.byId(sw.id), k = (t - sw.t0) / 0.22;
    if (!c || k > 1) { swings.splice(i, 1); continue; }
    const s = toScreen(c.pos.x + c.facing * c.size.x * 0.12, c.pos.y + c.size.y * 0.42);
    ctx.save();
    ctx.translate(Math.round(s.x), Math.round(s.y));
    if (c.facing < 0) ctx.scale(-1, 1);
    ctx.rotate(-1.3 + 3.2 * (1 - (1 - k) * (1 - k)));
    PICK.forEach((row, y) => [...row].forEach((ch, x) => { const col = PICK_COLORS[ch]; if (col) { ctx.fillStyle = col; ctx.fillRect((x - 4.5) * PX, (y - PICK.length) * PX, PX, PX); } }));
    ctx.restore();
  }
}

// ---------------------------------------------------------------- bubbles & drawing

function say(id, text, secs) {
  for (const b of bubbles.filter((b) => b.id === id)) { b.el.remove(); bubbles.splice(bubbles.indexOf(b), 1); }
  const el = document.createElement('div');
  el.className = 'say'; el.textContent = text;
  bubbleHost.appendChild(el);
  bubbles.push({ el, id, until: performance.now() / 1000 + secs });
}

function handleEvents(events) {
  for (const e of events) {
    const c = world.byId(e.id ?? e.rider ?? e.a);
    if (!c) continue;
    const top = V(c.pos.x, c.pos.y + c.size.y * 0.8);
    if (e.type === 'poked' || e.type === 'petted' || e.type === 'stacked') particles.burst(FX.heart, top, { dy: [24, 32], duration: 1.1 });
    else if (e.type === 'dizzy') particles.orbit(() => V(c.pos.x, c.pos.y + c.size.y * 0.72));
    else if (e.type === 'danceBeat') particles.burst(null, top, { imgs: [FX.note, FX.note2], dx: [-18, 18], dy: [18, 30], duration: 1 });
    else if (e.type === 'special') particles.burst(null, top, { imgs: [FX.sparkle, FX.smallStar], count: 5, dx: [-26, 26], dy: [-8, 26], duration: 0.8, stagger: 0.05 });
  }
}

let last = 0;
function frame(now) {
  if (!running) return;
  const dt = Math.min(0.05, (now - last) / 1000 || 0);
  last = now;
  steer(dt);
  world.step(dt);
  handleEvents(world.drainEvents());
  particles.update(dt);
  chores += dt;
  if (chores > 0.5) {
    chores = 0;
    scan();
    const busy = settings.debugRate ? 20 : 1;     // tests turn this up
    if (Math.random() < 0.06 * busy) nibble();
    if (Math.random() < 0.045 * busy) plant();
  }
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  ctx.clearRect(0, 0, W, H);
  ctx.imageSmoothingEnabled = false;
  drawMining(now / 1000, dt);
  for (const b of bites) {
    const el = elById.get(b.id);
    if (!el) continue;
    const r = el.getBoundingClientRect();
    ctx.fillStyle = b.color; ctx.fillRect(Math.round(r.left + b.dx), Math.round(r.top + b.dy), Math.ceil(b.w), Math.ceil(b.h));
  }
  drawGarden(now);
  for (const c of world.creatures) {
    const a = art.get(c.id), r = a?.rects[c.boosting ? c.species.frame('fly', c.animTime) : c.currentFrame];
    if (!r) continue;
    const w = r.w * PX, h = r.h * PX, s = toScreen(c.pos.x, c.pos.y);
    ctx.save();
    ctx.translate(Math.round(s.x), Math.round(s.y));
    if (c.facing < 0) ctx.scale(-1, 1);
    ctx.drawImage(a.image, r.x, r.y, r.w, r.h, -w / 2, -h, w, h);
    ctx.restore();
    if (c.id === driven) {
      const m = toScreen(c.pos.x, c.pos.y + c.size.y + 8 + Math.abs(Math.sin(now / 200)) * 4);
      ctx.fillStyle = '#ff7a4d';
      for (let row = 0; row < 3; row++) ctx.fillRect(Math.round(m.x) - (3 - row) * 2, Math.round(m.y) - (3 - row) * 2, (6 - row * 2) * 2 + 2, 2);
    }
  }
  particles.draw(ctx, toScreen, PX);
  const t = now / 1000;
  for (let i = bubbles.length - 1; i >= 0; i--) {
    const b = bubbles[i], c = world.byId(b.id);
    if (!c || t > b.until) { b.el.remove(); bubbles.splice(i, 1); continue; }
    const s = toScreen(c.pos.x, c.pos.y + c.size.y + 6);
    b.el.style.left = Math.round(Math.min(W - 40, Math.max(40, s.x))) + 'px';
    b.el.style.top = Math.round(Math.max(26, s.y)) + 'px';
  }
  raf = requestAnimationFrame(frame);
}

// ---------------------------------------------------------------- lifecycle

function mount() {
  root = document.createElement('div');
  root.id = 'gremlets-root';
  root.style.cssText = 'all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483646;';
  const sh = root.attachShadow({ mode: 'open' });
  sh.innerHTML = `<style>
    canvas{position:fixed;inset:0;pointer-events:none;image-rendering:pixelated}
    canvas.live{pointer-events:auto;cursor:grab} canvas.grab{cursor:grabbing}
    .say{position:fixed;transform:translate(-50%,-100%);background:#fffdf8;color:#1d211e;border:2px solid #1d211e;border-radius:8px;padding:2px 8px;
      font:700 12px/1.35 -apple-system,BlinkMacSystemFont,system-ui,sans-serif;white-space:nowrap;pointer-events:none}
    .hint{position:fixed;left:50%;bottom:14px;transform:translateX(-50%);background:rgba(255,122,77,.96);color:#fff;padding:7px 13px;border-radius:999px;
      font:600 12.5px -apple-system,BlinkMacSystemFont,system-ui,sans-serif;pointer-events:none;white-space:nowrap}
    [hidden]{display:none!important}
  </style><canvas></canvas><div class="bubbles"></div><div class="hint" hidden></div>`;
  canvas = sh.querySelector('canvas'); ctx = canvas.getContext('2d');
  bubbleHost = sh.querySelector('.bubbles'); hint = sh.querySelector('.hint');
  document.documentElement.appendChild(root);
}

function stop() {
  running = false;
  driven = null;
  cancelAnimationFrame(raf);
  root?.remove();
  window.__gremletsLoading = false;
  window.__gremlets = null;
}

export async function start() {
  if (running) return;
  running = true;
  mount();
  settings = { ...settings, ...(await store.get('settings', {})) };
  garden = await store.get(GARDEN_KEY, []);
  resize();
  wireInput();
  syncCount();
  chrome.storage.onChanged.addListener((ch) => {
    if (ch.settings) { settings = { ...settings, ...ch.settings.newValue }; syncCount(); }
    if (ch[GARDEN_KEY]) { garden = ch[GARDEN_KEY].newValue || []; anchors.clear(); }
  });
  window.__gremlets = { toggle: stop, world, get driven() { return driven; }, takeControl, get garden() { return garden; }, get bites() { return bites; }, plant, nibble, swing, keys, get holes() { return holes; } };
  last = performance.now();
  raf = requestAnimationFrame(frame);
}
