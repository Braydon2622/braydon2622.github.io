import AppKit
import Network
import Carbon.HIToolbox
import ServiceManagement
import GremletsCore

final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate {
    private var species: [String: LoadedSpecies] = [:]
    private let world = World()
    private var overlay: OverlayController!
    private var statusItem: NSStatusItem!
    private var defaultStatusImage: NSImage?
    private var lastIconSwap: CFTimeInterval = 0
    private var timer: Timer?
    private var currentRate: Double = 0
    private var lastTick = CACurrentMediaTime()
    private var lastWindowPoll: Double = 0
    private var lastWindowChange: Double = -10
    private var lastWindowSignature: [Int: Rect] = [:]
    private var paused = false
    private let perf = PerfMonitor(enabled: ProcessInfo.processInfo.environment["GREMLETS_PERF"] == "1")

    private let rosterKey = "roster"

    // Companion features.
    private let bonds = BondStore()
    private let focus = FocusTimer()
    private var control: ControlServer?
    private var lastHousekeeping = CACurrentMediaTime()
    private var lastTitle: String? = ""
    private var remindersOn: Bool {
        get { UserDefaults.standard.bool(forKey: "reminders") }
        set { UserDefaults.standard.set(newValue, forKey: "reminders") }
    }
    private var lastReminder = Date()
    /// Little events (meteor showers, festivals, the ferry, the merchant) on or off.
    private var epicEvents: Bool {
        get { UserDefaults.standard.object(forKey: "events.epic") as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: "events.epic") }
    }
    private let groveKey = "grove.v1"
    private let bonsaiKey = "bonsai.v1"
    private var bonsaiDirty = false
    private var nextReminderIsWater = true

    // Ownership: NFT holders keep their Gremlets; everyone else can try any Gremlet in a demo.
    private var access = Access(tokens: [:], gatingEnabled: false)
    private var wallet: WalletLink?
    private var demoNotice: String?

    // Presence: hide on calls / boss key, nap while you're away, calmer on Low Power Mode.
    private var presence = PresenceTracker()
    private var manuallyHidden = false
    private var hideHotKey: HotKey?
    private let focusLog = FocusLogStore()
    private let phone = PhoneLink()
    private let bridge = ScreenBridge()
    private let sense = ScreenSense()
    private var compactPreviewUntil: CFTimeInterval = 0
    /// Gremlets visiting from a friend's Mac (creature id → their home Mac's id).
    private var guests: [Int: String] = [:]
    /// When each visitor arrived (they go home after a few minutes), when one of ours last went visiting, and whether
    /// the other screen was open last time we looked (the moment it opens is a little event of its own).
    private var guestSince: [Int: CFTimeInterval] = [:]
    private var nextVisitAt: CFTimeInterval = 0
    private var peerWasOnline = false
    let dock = DockWatcher()
    private var liftKeysSince: CFTimeInterval?
    private lazy var weatherService = WeatherService(world: world)
    /// Watching the Mac: battery, the network, the screenshot tool.
    private let netMonitor = NWPathMonitor()
    private var online: Bool?
    private var batteryLowShown = false
    private var lastBatteryCheck: CFTimeInterval = 0
    private var screenshotWasVisible = false
    private var lastDoorCheck: CFTimeInterval = 0
    private let icons = DesktopIcons()
    private let controls = AppControls()
    private let dayLog = DayLog()
    private let sounds = GardenSounds()
    private var soundsAllowed: Bool { sounds.enabled && !focus.isFocusing && !presence.isHidden && !paused }
    private var dailyPostcardTried = false
    private var seasonOverride: (Int, Date)?
    private var nightOverride: (Bool, Date)?
    private let launchTime = CACurrentMediaTime()
    private lazy var showcase: Showcase = {
        let sc = Showcase(world: world, buddy: buddy)
        sc.onFinish = { [weak self] in self?.rebuildMenu() }
        return sc
    }()
    private let companion = CompanionAI()
    private var lastMorning = UserDefaults.standard.string(forKey: "companion.lastMorning") ?? ""
    private var lastEvening = UserDefaults.standard.string(forKey: "companion.lastEvening") ?? ""
    private lazy var buddy: ClaudeBuddy = {
        let b = ClaudeBuddy(world: world, overlay: overlay)
        b.onChange = { [weak self] in self?.rebuildMenu() }
        b.onSessionEnded = { [weak self] r, after in self?.sessionEnded(r, after: after) }
        b.onState = { [weak self] session, project, state in self?.claudeState(session: session, project: project, state: state) }
        return b
    }()

    // MARK: The Terrarium (docs/plans/TERRARIUM.md)

    /// What each Claude session is doing, for a Terrarium iPad on the bridge.
    let terrariumBoard: TerrariumBoard = {
        let b = TerrariumBoard()
        if let d = UserDefaults.standard.dictionary(forKey: "terrarium.aliases") as? [String: Int] { b.aliases = d }
        return b
    }()
    private var terrariumNames: Bool {
        get { UserDefaults.standard.bool(forKey: "terrarium.names") }
        set { UserDefaults.standard.set(newValue, forKey: "terrarium.names") }
    }

    /// A Claude session changed state: the Terrarium hears about it (and the Back Office's Workshop).
    private func claudeState(session: String, project: String, state: TerrariumStatus.State?) {
        let now = Date().timeIntervalSince1970
        if terrariumBoard.record(session: session, project: project, state: state, at: now) {
            UserDefaults.standard.set(terrariumBoard.aliases, forKey: "terrarium.aliases")
            bridge.sendStatus(terrariumBoard.snapshot(showNames: terrariumNames).json())
        }
    }

    @objc private func makeTerrarium() {
        if !bridge.linked || !bridge.sealed { bridge.create(side: bridge.side ?? "right"); updateDoor() }
        if let url = URL(string: "http://127.0.0.1:\(ControlServer.defaultPort)/terrarium") { NSWorkspace.shared.open(url) }
        rebuildMenu()
    }

    @objc private func toggleTerrariumNames() {
        terrariumNames.toggle()
        bridge.sendStatus(terrariumBoard.snapshot(showNames: terrariumNames).json())
        rebuildMenu()
    }
    private var hideDuringCalls: Bool {
        get { UserDefaults.standard.object(forKey: "hideDuringCalls") as? Bool ?? true }
        set { UserDefaults.standard.set(newValue, forKey: "hideDuringCalls") }
    }

    func applicationDidFinishLaunching(_ note: Notification) {
        world.gardenInMoss = true; world.topCornerPerches = true; world.dayFollowsClaude = true; world.crittersOn = true
        // The tidy desktop: no village or road on the floor, no vines up the screen's sides, one small corner plant.
        world.villageOn = false
        world.railsOn = false
        world.edgeVines = false
        world.rotateGrove = true
        species = SpriteLibrary.loadAll()
        guard !species.isEmpty else {
            let alert = NSAlert()
            alert.messageText = "No Gremlet sprites found"
            alert.informativeText = "Expected sprite sheets in the app's Species folder or \(SpriteLibrary.userSpeciesFolder.path)."
            alert.runModal()
            NSApp.terminate(nil)
            return
        }
        overlay = OverlayController(world: world, species: species)
        overlay.onGardenChange = { [weak self] in self?.rebuildMenu() }
        overlay.onWorkerClicked = { [weak self] c in self?.focusSession(of: c) }
        refreshEnvironment()
        world.loadGrove(UserDefaults.standard.data(forKey: groveKey).flatMap(Grove.decode) ?? Grove())
        // A fresh Mac starts with a little moss already creeping in, so there's something to see (and tend) at once.
        world.mossMinutes = UserDefaults.standard.object(forKey: mossKey) as? Double ?? 45
        world.mossCare = UserDefaults.standard.object(forKey: "moss.care") as? Double ?? 1
        world.houseDaisies = UserDefaults.standard.integer(forKey: "house.daisies")
        world.pantry = UserDefaults.standard.integer(forKey: "house.pantry")
        world.homeCare = UserDefaults.standard.integer(forKey: "house.care")
        if let b = UserDefaults.standard.object(forKey: "house.barrel") as? Double { world.rainBarrel = b }
        if let p = UserDefaults.standard.string(forKey: "house.patch") { world.patchSaved = p }
        if let p = UserDefaults.standard.string(forKey: "house.seeds") { world.seedTinSaved = p }
        world.porchLeaves = UserDefaults.standard.double(forKey: "house.leaves")
        world.roofSnow = UserDefaults.standard.double(forKey: "house.snow")
        world.fireflyJar = UserDefaults.standard.integer(forKey: "house.jar")
        if let d = UserDefaults.standard.data(forKey: "house.mail"), let m = try? JSONDecoder().decode([Postcard].self, from: d) { world.mailbox = m }
        if let d = UserDefaults.standard.data(forKey: "winFlags.v1"), let f = try? JSONDecoder().decode([WinFlag].self, from: d) { world.loadWinFlags(f) }
        world.houseDaisiesDay = UserDefaults.standard.integer(forKey: "house.daisiesDay")
        // Houses built by older versions take the shape of today's pictures.
        world.refitHouses { h in Biome(rawValue: h.biome).map { BuildArt.fit($0) } }
        let storedSide = UserDefaults.standard.object(forKey: "nursery.side") as? Double ?? 0
        world.nurserySide = storedSide == 0 ? 1 : storedSide
        world.loadBonsai(UserDefaults.standard.data(forKey: bonsaiKey).flatMap(BonsaiBook.decode) ?? BonsaiBook())
        setUpAccess()
        restoreRoster()
        setUpCompanion()
        setUpMenuBar()

        NotificationCenter.default.addObserver(forName: NSApplication.didChangeScreenParametersNotification, object: nil, queue: .main) { [weak self] _ in
            self?.overlay.rebuildScreens()
            self?.refreshEnvironment()
        }
        // Spaces switch: the visible windows change all at once, so re-read them right away.
        NSWorkspace.shared.notificationCenter.addObserver(forName: NSWorkspace.activeSpaceDidChangeNotification, object: nil, queue: .main) { [weak self] _ in
            self?.refreshEnvironment()
        }
        schedule(rate: 60)
    }

    // MARK: Loop

    private func schedule(rate: Double) {
        guard rate != currentRate else { return }
        currentRate = rate
        timer?.invalidate()
        let t = Timer(timeInterval: 1 / rate, repeats: true) { [weak self] _ in self?.tick() }
        t.tolerance = 0.2 / rate // let macOS coalesce wakeups to save power
        RunLoop.main.add(t, forMode: .common)
        timer = t
    }

    private func tick() {
        let now = CACurrentMediaTime()
        let dt = now - lastTick
        lastTick = now
        if now - lastHousekeeping >= 1 { housekeeping(elapsed: now - lastHousekeeping); lastHousekeeping = now }
        guard !paused, !presence.isHidden else {
            if presence.isHidden { schedule(rate: 2) }   // nothing on screen: just keep an ear out for "show"
            return
        }

        // Window polling is the most expensive thing we do, so its rate adapts: fast while a window that a
        // creature stands on is moving (so riding a dragged window is smooth), slow otherwise.
        let movingRecently = now - lastWindowChange < 0.6
        // Window frames matter most for creatures standing on a window (they ride it); otherwise they only
        // affect jump targets and landings, which tolerate a few hundred ms of staleness.
        let anyoneOnWindow = world.creatures.contains { ($0.groundOwner ?? -1) >= 0 || $0.activity == .airborne || $0.job?.windowID != nil }
        let pollInterval = movingRecently ? 1.0 / 60 : (anyoneOnWindow ? 0.1 : 0.35)
        if now - lastWindowPoll >= pollInterval { refreshEnvironment() }

        world.cursor = Vec2(Double(NSEvent.mouseLocation.x), Double(NSEvent.mouseLocation.y))
        world.wallClock = Date().timeIntervalSince1970
        // The cursor elevator: while ⌃⌥ (and nothing else) is held with no button down, a cloud rides under the pointer.
        let mods = NSEvent.modifierFlags.intersection([.control, .option, .command, .shift])
        // Held for half a second first, so a quick ⌃⌥ shortcut (like ⌃⌥G) doesn't launch anyone.
        let held = mods == [.control, .option] && NSEvent.pressedMouseButtons == 0 && !paused && !manuallyHidden
        if held { if liftKeysSince == nil { liftKeysSince = now } } else { liftKeysSince = nil }
        let lifting = held && now - (liftKeysSince ?? now) >= 0.5
        if lifting || world.lift != nil { world.setLift(lifting ? world.cursor : nil); schedule(rate: 60) }
        world.step(dt)
        let events = world.drainEvents()
        trackBond(events)
        overlay.handle(events)
        let groveEvents = world.drainGroveEvents()
        overlay.fx.handle(groveEvents)
        if !showcase.running {
            for e in groveEvents {
                if case .fed = e { dayLog.add { $0.tasks += 1 } }
                if case .houseAdded = e { dayLog.add { $0.houses += 1 }; if soundsAllowed { sounds.play(.house) } }
            }
        }
        if groveEvents.contains(where: {
            switch $0 { case .fed, .wish, .houseAdded, .planted, .cornerCleared: return true; default: return false }
        }) { saveGrove() }
        overlay.fx.handle(world.drainSpectacleEvents())
        overlay.handleClaude(world.drainClaudeEvents())
        let growth = world.drainBonsaiEvents()
        if !growth.isEmpty {
            overlay.bonsaiFX.handle(growth); bonsaiDirty = true
            if soundsAllowed {
                for e in growth {
                    switch e {
                    case .grew(_, "bloom", _): sounds.play(.bloom)
                    case .grew(_, "fruit", _): sounds.play(.fruit)
                    case .sprouted: sounds.play(.sprout)
                    case .milestone: sounds.play(.milestone)
                    default: break
                    }
                }
            }
            if !showcase.running {
                var leavesByProject: [String: Int] = [:]
                for case .grew(let p, "leaf", _) in growth { leavesByProject[p, default: 0] += 1 }
                let leaves = leavesByProject.values.reduce(0, +)
                if leaves > 0 {
                    dayLog.add { d in
                        d.edits += leaves
                        var pr = d.projects ?? [:]
                        for (p, n) in leavesByProject { pr[p, default: 0] += n }
                        d.projects = pr
                    }
                }
            }
        }
        overlay.fx.handle(world.drainBuildEvents())
        overlay.fx.handle(world.drainTerrainEvents())
        let runs = world.drainExpeditionEvents()
        overlay.fx.handle(runs)
        for e in runs {
            if case .started(_, let goal, _) = e { sense.startClip(goal == .summit ? "Summit" : "Treasure run", seconds: 26) }
        }
        let team = world.drainTeamEvents()
        overlay.fx.handle(team)
        for e in team {
            if case .boostStarted = e { sense.startClip("Boost", seconds: 12) }
        }
        let mossEvents = world.drainMossEvents(), sproutEvents = world.drainSproutEvents()
        overlay.fx.handle(mossEvents)
        overlay.fx.handle(sproutEvents)
        Scrapbook.record(sproutEvents, moss: mossEvents, into: dayLog)
        overlay.fx.handle(world.drainGardenEvents())
        overlay.ecoFX.handle(world.drainEcoEvents())
        let home = world.drainHomeEvents()
        overlay.ecoFX.handle(home)
        if !showcase.running, !home.isEmpty { recordHome(home) }
        updateTyping()
        overlay.fx.handle(world.drainPlanEvents())
        sense.tick(frontWindow: frontWindowForSense())
        sense.clipTick()
        watchTheMac()
        let mossNow = CACurrentMediaTime()
        if mossNow - lastMossSave > 30 { lastMossSave = mossNow; saveMoss() }
        // The doorway to a linked screen: open while the other screen is around; whoever walks through it goes over.
        let doorNow = CACurrentMediaTime()
        if doorNow - lastDoorCheck > 5 { lastDoorCheck = doorNow; updateDoor() }
        for c in world.creaturesPastDoor() { crossOut(c) }
        let trades = world.drainMerchantEvents()
        overlay.fx.handle(trades)
        if trades.contains(where: { if case .sold = $0 { return true }; return false }) { saveGrove(); rebuildMenu() }
        let adventures = world.drainAdventureEvents()
        overlay.fx.handle(adventures)
        for case .ferryCrossed(let riders, let y) in adventures { ferryCrossedOut(riders: riders, yFrac: y) }
        if adventures.contains(where: { if case .gemFound = $0 { return true }; return false }) {
            saveGrove(); rebuildMenu()
            if soundsAllowed { sounds.play(.gem) }
            if !showcase.running { dayLog.add { $0.gems += adventures.filter { if case .gemFound = $0 { return true }; return false }.count } }
        }
        overlay.render()
        overlay.updateClickThrough()
        perf.tick(now: now, rate: currentRate)

        var wanted = movingRecently || overlay.isInteracting ? 60 : world.desiredTickRate
        if overlay.hasBubbles { wanted = max(wanted, 30) }
        if world.spectacle != nil || !world.playBalls.isEmpty || world.ferry != nil || world.merchant != nil || showcase.running || world.creatures.contains(where: { $0.grapple != nil || $0.gliding }) { wanted = 60 }
        if overlay.hasProps { wanted = max(wanted, 12) }   // creations follow their window   // keep a speech bubble following its Gremlet smoothly
        if let cap = presence.maxTickRate(presenceInput()), !overlay.isInteracting { wanted = min(wanted, cap) }
        schedule(rate: wanted)
    }

    private func refreshEnvironment() {
        lastWindowPoll = CACurrentMediaTime()
        var wins = WindowTracker.snapshot()
        if sense.standOnText {
            for i in wins.indices { wins[i].spans = sense.spans(for: wins[i].id, size: CGSize(width: wins[i].frame.w, height: wins[i].frame.h)) }
        }
        var sig: [Int: Rect] = [:]
        for w in wins { sig[w.id] = w.frame }
        if sig != lastWindowSignature {
            // Only count it as "moving" if a window someone is standing on changed.
            let ridden = Set(world.creatures.compactMap { $0.groundOwner }.filter { $0 >= 0 })
            if ridden.contains(where: { lastWindowSignature[$0] != sig[$0] }) { lastWindowChange = lastWindowPoll }
            lastWindowSignature = sig
        }
        var extra: [Surface] = []
        if icons.enabled {
            icons.updateVisibility(windows: wins)
            extra = icons.surfaces(excluding: overlay.liftedIcons)
        }
        // Real controls in the front app (address bars, search fields, buttons), if you've turned it on.
        extra += controls.surfaces(now: CACurrentMediaTime())
        if !extra.isEmpty || !world.iconSurfaces.isEmpty { world.iconSurfaces = extra }
        // Full screen (an app filling the whole main screen, menu bar and all): everything keeps to the corners, and
        // the floor is the true bottom of the screen (the Dock is tucked away).
        let isFull = WindowTracker.fullScreenSpace || CACurrentMediaTime() < compactPreviewUntil
        // The hanging house: under the notch normally; in the top-right corner while an app is full screen.
        world.notchHome = isFull ? Self.cornerHome() : Self.notchHome()
        // (Below the notch band, where a full-screen app's content starts.)
        let screens = isFull ? NSScreen.screens.map { s -> Rect in
            let top: Double
            if #available(macOS 12, *) { top = Double(s.safeAreaInsets.top) } else { top = 0 }
            return Rect(x: s.frame.minX, y: s.frame.minY, w: s.frame.width, h: s.frame.height - top)
        } : WindowTracker.screens()
        world.setEnvironment(screens: screens, windowsFrontToBack: wins, menuBars: isFull ? [] : MenuBarSense.bars())
        // Switched only after the screens are in place, so the floats in and out of full screen aim at the real
        // floor and the real perches.
        if isFull != world.compact { world.compact = isFull; schedule(rate: 60) }
    }

    // MARK: Roster

    private func restoreRoster() {
        let args = CommandLine.arguments
        var ids: [String]
        if let i = args.firstIndex(of: "--spawn"), i + 1 < args.count {
            ids = args[i + 1].split(separator: ",").map(String.init)
        } else {
            ids = UserDefaults.standard.stringArray(forKey: rosterKey) ?? []
        }
        ids = ids.filter { species[$0] != nil && !phone.onPhone.contains($0) && !bridge.away.contains($0) }
        if ids.isEmpty {
            // First launch: your own Gremlets if you have any, otherwise the three starters as a demo.
            let owned = access.ownedSpecies.filter { species[$0] != nil }.sorted()
            ids = owned.isEmpty ? ["kindlet", "flurrie", "dandelet"].filter { species[$0] != nil } : Array(owned.prefix(3))
        }
        if ids.isEmpty, let first = species.keys.sorted().first { ids = [first] }
        ids = access.filterRestore(ids)
        for id in ids {
            world.spawn(species[id]!.info)
            if access.isDemo(id) { access.noteDemoAdded(now: Date().timeIntervalSince1970) }
        }
        saveRoster()
    }

    private func saveRoster() {
        // A friend's visiting Gremlets aren't yours to keep: they stay out of the saved roster.
        UserDefaults.standard.set(world.creatures.filter { guests[$0.id] == nil }.map(\.species.id), forKey: rosterKey)
    }

    // MARK: Menu bar

    private func setUpMenuBar() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        let img = MenuLogo.image(.idle)
        statusItem.button?.image = img
        defaultStatusImage = img
        statusItem.button?.toolTip = "Gremlets"
        rebuildMenu()
    }

    func menuWillOpen(_ menu: NSMenu) {
        guard menu === statusItem.menu else { return }
        // Refresh in place so countdowns are current (swapping the menu object while it opens isn't allowed).
        menu.removeAllItems()
        for item in buildMenuItems() { menu.addItem(item) }
    }

    private func rebuildMenu() {
        guard statusItem != nil else { return }      // callbacks can fire during launch, before the menu bar item exists
        let menu = NSMenu()
        menu.delegate = self
        for item in buildMenuItems() { menu.addItem(item) }
        statusItem.menu = menu
    }

    private func buildMenuItems() -> [NSMenuItem] {
        // Kept short: the everyday things up top, then Settings (a few plain switches) and More (everything else).
        let menu = NSMenu(), settings = NSMenu(), more = NSMenu(), focusMenu = NSMenu()
        var headerText = "Gremlets: \(world.creatures.count) out" + (world.mossMinutes >= 10 ? (world.mossThirsty ? " · the moss is thirsty" : " · the moss is thriving") : "")
        switch presence.hidden {
        case .call?: headerText = "Gremlets: hiding while you're on a call"
        case .manual?: headerText = "Gremlets: hidden (⌃⌥G to bring them back)"
        case nil: if presence.isAway { headerText += " · napping until you're back" }
        }
        if let card = world.postcard {
            let pc = NSMenuItem(title: "💌 A postcard from \(card.from)", action: #selector(openPostcard), keyEquivalent: "")
            pc.target = self
            menu.addItem(pc)
        }
        let header = NSMenuItem(title: headerText, action: nil, keyEquivalent: "")
        header.isEnabled = false
        menu.addItem(header)

        menu.addItem(.separator())
        let add = NSMenuItem(title: "Add a Gremlet", action: nil, keyEquivalent: "")
        let sub = NSMenu()
        // Group the 50 species by family so the menu stays browsable.
        let families: [(String, String)] = [("animal", "Animals"), ("insect", "Insects & Bugs"), ("dragon", "Dragons"),
                                            ("dino", "Dinosaurs"), ("mythic", "Mythical Beasts"), ("spirit", "Spirits"), ("guardian", "Guardians")]
        let known = Set(families.map(\.0))
        for (key, title) in families + [("", "Custom")] {
            let members = species.values
                .filter { key.isEmpty ? !known.contains($0.info.family) : $0.info.family == key }
                .sorted { $0.info.name < $1.info.name }
            guard !members.isEmpty else { continue }
            let famItem = NSMenuItem(title: "\(title) (\(members.count))", action: nil, keyEquivalent: "")
            let famMenu = NSMenu()
            for sp in members {
                let kind = access.kind(sp.info.id)
                let item = NSMenuItem(title: "\(sp.info.name)  ·  \(sp.info.element)\(kind == .demo ? "  ·  demo" : "")", action: #selector(addCreature(_:)), keyEquivalent: "")
                item.target = self
                item.representedObject = sp.info.id
                item.image = NSImage(cgImage: sp.frames[0], size: NSSize(width: 22, height: 22))
                item.toolTip = sp.info.blurb
                if kind == .owned { item.state = .on; item.toolTip = "Yours (you hold this Gremlet). " + sp.info.blurb }
                famMenu.addItem(item)
            }
            famItem.submenu = famMenu
            sub.addItem(famItem)
        }
        sub.addItem(.separator())
        let party = NSMenuItem(title: access.gatingEnabled ? "Surprise Party (random)" : "Surprise Party (5 random)", action: #selector(addRandomParty), keyEquivalent: "")
        party.target = self
        sub.addItem(party)
        add.submenu = sub
        menu.addItem(add)

        if !world.creatures.isEmpty {
            let remove = NSMenuItem(title: "Send One Home", action: nil, keyEquivalent: "")
            let rsub = NSMenu()
            for c in world.creatures {
                let item = NSMenuItem(title: "\(c.species.name) #\(c.id)", action: #selector(removeCreature(_:)), keyEquivalent: "")
                item.target = self
                item.representedObject = c.id
                rsub.addItem(item)
            }
            remove.submenu = rsub
            menu.addItem(remove)
        }

        // Your Gremlets: bond with each one that's out.
        if !world.creatures.isEmpty {
            let mine = NSMenuItem(title: "Your Gremlets", action: nil, keyEquivalent: "")
            let msub = NSMenu()
            var seen = Set<String>()
            for c in world.creatures where seen.insert(c.species.id).inserted {
                let b = bonds.bond(c.species.id)
                let hearts = String(repeating: "♥", count: b.level + 1) + String(repeating: "♡", count: 4 - b.level)
                let item = NSMenuItem(title: "\(c.species.name)   \(hearts)  \(b.name)", action: nil, keyEquivalent: "")
                if let img = species[c.species.id]?.frames.first { item.image = NSImage(cgImage: img, size: NSSize(width: 22, height: 22)) }
                let detail = NSMenu()
                let hours = b.hoursTogether < 1 ? "\(Int(b.hoursTogether * 60)) min" : String(format: "%.1f h", b.hoursTogether)
                var lines = ["Together \(b.daysTogether) day\(b.daysTogether == 1 ? "" : "s") · \(hours)",
                             "Petted \(b.pets)× · Poked \(b.pokes)×"]
                if let next = b.pointsToNext { lines.append("\(Int(next.rounded(.up))) points to \(Bond.levelNames[b.level + 1])") }
                else { lines.append("The closest bond there is") }
                if b.level >= 2 { lines.append("Shows off its signature move when petted") }
                for l in lines { let li = NSMenuItem(title: l, action: nil, keyEquivalent: ""); li.isEnabled = false; detail.addItem(li) }
                item.submenu = detail
                msub.addItem(item)
            }
            let tip = NSMenuItem(title: "Pet them (rub the cursor over them) · hold ⌃⌥ to give one a ride on your pointer", action: nil, keyEquivalent: "")
            tip.isEnabled = false
            msub.addItem(.separator()); msub.addItem(tip)
            mine.submenu = msub
            more.addItem(mine)
        }
        let wallet = walletMenuItems()
        if !wallet.isEmpty { more.addItem(.separator()); for item in wallet { more.addItem(item) } }

        // Focus buddy.
        if let label = focus.label {
            let state = NSMenuItem(title: focus.isFocusing ? "Focusing · \(label) left" : label + " left", action: nil, keyEquivalent: "")
            state.isEnabled = false
            focusMenu.addItem(state)
            let stop = NSMenuItem(title: "Stop Focus Timer", action: #selector(stopFocus), keyEquivalent: "")
            stop.target = self
            focusMenu.addItem(stop)
        } else {
            for m in [25, 50] {
                let f = NSMenuItem(title: "Focus for \(m) min", action: #selector(startFocus(_:)), keyEquivalent: "")
                f.target = self
                f.representedObject = m
                focusMenu.addItem(f)
            }
        }
        let mins = Int(focusLog.todayMinutes.rounded()), streak = focusLog.streak
        if mins > 0 || streak > 0 {
            let line = "Today: \(mins) min focused" + (streak > 0 ? " · \(streak)-day streak" : "")
            let st = NSMenuItem(title: line, action: nil, keyEquivalent: "")
            st.isEnabled = false
            st.toolTip = "Gremlets that keep you company through a focus session grow closer to you."
            focusMenu.addItem(st)
        }
        let ic = NSMenuItem(title: "Play with Desktop Icons", action: #selector(toggleIcons), keyEquivalent: "")
        ic.target = self
        ic.state = icons.enabled ? .on : .off
        ic.toolTip = icons.lastError ?? "Gremlets sit on your desktop icons, make them boing, and borrow them for a bit. Nothing on your desktop is moved. macOS will ask once to let Gremlets read icon positions from Finder."
        settings.addItem(ic)
        if icons.enabled, let err = icons.lastError {
            let e = NSMenuItem(title: "  ⚠︎ " + err, action: nil, keyEquivalent: ""); e.isEnabled = false
            settings.addItem(e)
        }
        let chat = NSMenuItem(title: "Chat with a Gremlet…", action: #selector(openChatMenu), keyEquivalent: "")
        chat.target = self
        chat.toolTip = "Talk with any of your Gremlets (or double-click one). Replies come from Claude when you add an API key."
        more.addItem(chat)
        let bud = NSMenuItem(title: "Help with Claude Code", action: #selector(toggleBuddy), keyEquivalent: "")
        bud.target = self
        bud.state = buddy.enabled ? .on : .off
        bud.toolTip = "While Claude Code works, a Gremlet works next to its window, and tells you when Claude is done or needs you."
        settings.addItem(bud)
        if let made = buddy.log.todaySummary {
            let m = NSMenuItem(title: "Made with Claude today: \(made)", action: nil, keyEquivalent: "")
            m.isEnabled = false
            menu.addItem(m)
        }
        more.addItem(.separator())
        more.addItem(groveMenuItem())
        more.addItem(bonsaiMenuItem())
        let journal = NSMenuItem(title: "Open Garden Journal", action: #selector(openJournal), keyEquivalent: "")
        journal.target = self
        journal.toolTip = "Your projects' trees and their stories, the village, the last two weeks of Claude work, and today's postcard. Stays on your Mac."
        more.addItem(journal)
        let scrap = NSMenuItem(title: "Open Scrapbook", action: #selector(openScrapbook), keyEquivalent: "")
        scrap.target = self
        scrap.toolTip = "A page a day with a flower pressed into it: what the Gremlets picked from the moss, the fireflies they caught, and what Claude got done. Stays on your Mac."
        more.addItem(scrap)
        let ctl = NSMenuItem(title: controls.enabled && !controls.trusted ? "Stand on Buttons and Search Bars · allow in System Settings" : "Stand on Buttons and Search Bars",
                             action: #selector(toggleControls), keyEquivalent: "")
        ctl.target = self
        ctl.state = controls.enabled ? .on : .off
        ctl.toolTip = "Gremlets can stand on the address bar, search fields and buttons of the app you're using. Needs Accessibility access (System Settings › Privacy & Security › Accessibility). Reads only where controls are, never what's in them, and skips web page content."
        // The seed book: which plants you've grown so far.
        let book = overlay.seedBook
        // Phone: pair, send a Gremlet over, see who's visiting.
        if !phone.isPaired {
            let pairItem = NSMenuItem(title: "Pair with Phone…", action: #selector(pairPhone), keyEquivalent: "")
            pairItem.target = self
            pairItem.toolTip = "Gremlets can hop over to your iPhone's web habitat and come back with what they grew."
            more.addItem(pairItem)
        } else {
            let ph = NSMenuItem(title: phone.connected ? "Phone · linked" : "Phone · connecting…", action: nil, keyEquivalent: "")
            let phMenu = NSMenu()
            if !world.creatures.isEmpty {
                let send = NSMenuItem(title: "Send to Phone", action: nil, keyEquivalent: "")
                let sendMenu = NSMenu()
                for c in world.creatures {
                    let it = NSMenuItem(title: c.species.name, action: #selector(sendToPhone(_:)), keyEquivalent: "")
                    it.target = self
                    it.representedObject = c.id
                    sendMenu.addItem(it)
                }
                send.submenu = sendMenu
                phMenu.addItem(send)
            }
            let away = phone.onPhone.compactMap { species[$0]?.info.name }
            if !away.isEmpty {
                let it = NSMenuItem(title: "On your phone: " + away.joined(separator: ", "), action: nil, keyEquivalent: "")
                it.isEnabled = false
                phMenu.addItem(it)
            }
            let show = NSMenuItem(title: "Show Pairing Code…", action: #selector(pairPhone), keyEquivalent: "")
            show.target = self
            phMenu.addItem(show)
            phMenu.addItem(.separator())
            let unlink = NSMenuItem(title: "Unlink Phone", action: #selector(unlinkPhone), keyEquivalent: "")
            unlink.target = self
            phMenu.addItem(unlink)
            ph.submenu = phMenu
            more.addItem(ph)
        }
        // Your Mac: the opt-in features that need a permission.
        var senseItems: [NSMenuItem] = []
        for (title, key, on, granted, tip) in [
            ("Stand on Text in Windows", "text", sense.standOnText, ScreenSense.hasScreenAccess,
             "Gremlets stand on lines of text in the front window. Needs Screen Recording; macOS shows a purple dot in the menu bar while it looks."),
            ("Save Highlight GIFs", "clips", sense.highlightClips, ScreenSense.hasScreenAccess,
             "Saves a short GIF of treasure runs and boosts to Movies › Gremlets. Needs Screen Recording, only while recording."),
        ] {
            let it = NSMenuItem(title: title + (on && !granted ? " · allow in System Settings" : ""), action: #selector(toggleSense(_:)), keyEquivalent: "")
            it.target = self; it.representedObject = key; it.state = on ? .on : .off; it.toolTip = tip
            senseItems.append(it)
        }
        // Weather where you are (off until you name a city).
        let wx = NSMenuItem(title: weatherService.summary.map { "Weather · " + $0 } ?? "Weather…", action: nil, keyEquivalent: "")
        wx.toolTip = "Rain splashes on your window tops, snow piles up along them, wind sends the kites up. Only shows where it lands, never across your work."
        let wxMenu = NSMenu()
        let setCity = NSMenuItem(title: weatherService.place == nil ? "Set Your City…" : "Change City…", action: #selector(askWeatherCity), keyEquivalent: "")
        setCity.target = self
        wxMenu.addItem(setCity)
        if weatherService.place != nil {
            let off = NSMenuItem(title: "Turn Weather Off", action: #selector(weatherOff), keyEquivalent: "")
            off.target = self
            wxMenu.addItem(off)
        }
        let note = NSMenuItem(title: "From Open-Meteo: only the city leaves your Mac", action: nil, keyEquivalent: "")
        note.isEnabled = false
        wxMenu.addItem(note)
        wx.submenu = wxMenu
        menu.addItem(wx)
        // Another screen (iPad, phone, a friend's laptop): a doorway at one edge of this screen.
        if !bridge.linked {
            let link = NSMenuItem(title: "Walk onto My iPad…", action: nil, keyEquivalent: "")
            link.toolTip = "Gremlets walk off one edge of your Mac and in from the edge of the other screen, and back."
            let lm = NSMenu()
            for (title, side) in [("It's to the right of my Mac", "right"), ("It's to the left of my Mac", "left")] {
                let it = NSMenuItem(title: title, action: #selector(linkScreen(_:)), keyEquivalent: "")
                it.target = self; it.representedObject = side
                lm.addItem(it)
            }
            link.submenu = lm
            menu.addItem(link)
            let friend = NSMenuItem(title: "Visit a Friend's Mac", action: nil, keyEquivalent: "")
            let fm = NSMenu()
            for (title, sel) in [("Invite a Friend…", #selector(inviteFriend)), ("Join a Friend's Code…", #selector(joinFriend))] {
                let it = NSMenuItem(title: title, action: sel, keyEquivalent: ""); it.target = self; fm.addItem(it)
            }
            friend.submenu = fm
            menu.addItem(friend)
            let terr = NSMenuItem(title: "Make an iPad a Terrarium…", action: #selector(makeTerrarium), keyEquivalent: "")
            terr.target = self
            terr.toolTip = "An iPad on the desk as a Gremlets home that stays on all day, showing what Claude is up to."
            menu.addItem(terr)
        } else {
            let other = bridge.peerIsMac ? "Friend's Mac" : "iPad"
            let st = NSMenuItem(title: bridge.peerOnline ? "\(other) linked · \(bridge.side ?? "right") edge" : "Link · waiting for the other screen…", action: nil, keyEquivalent: "")
            let lm = NSMenu()
            let away = bridge.away.compactMap { species[$0]?.info.name }
            if !away.isEmpty {
                let it = NSMenuItem(title: "On the other screen: " + away.joined(separator: ", "), action: nil, keyEquivalent: "")
                it.isEnabled = false
                lm.addItem(it)
            }
            if bridge.peerOnline {
                let go = NSMenuItem(title: "Send One Over Now", action: #selector(crossNow), keyEquivalent: "")
                go.target = self
                lm.addItem(go)
            }
            let show = NSMenuItem(title: "Show Link Code…", action: #selector(showLinkCode), keyEquivalent: "")
            show.target = self
            lm.addItem(show)
            let terr = NSMenuItem(title: bridge.peerIsTerrarium ? "Terrarium Link Code…" : "Make It a Terrarium…", action: #selector(makeTerrarium), keyEquivalent: "")
            terr.target = self
            lm.addItem(terr)
            let names = NSMenuItem(title: "Show Project Names on the Terrarium", action: #selector(toggleTerrariumNames), keyEquivalent: "")
            names.target = self; names.state = terrariumNames ? .on : .off
            names.toolTip = "Off: the Terrarium shows \"Project 1\", \"Project 2\" instead of your project names."
            lm.addItem(names)
            lm.addItem(.separator())
            let unlink = NSMenuItem(title: "Unlink Screen", action: #selector(unlinkScreen), keyEquivalent: "")
            unlink.target = self
            lm.addItem(unlink)
            st.submenu = lm
            menu.addItem(st)
        }
        let sb = NSMenuItem(title: "Seed Book (\(book.found)/\(PlantKind.allCases.count))", action: nil, keyEquivalent: "")
        let sbMenu = NSMenu()
        for rarity in 0...4 {
            if rarity > 0 { sbMenu.addItem(.separator()) }
            for k in PlantKind.allCases where k.rarity == rarity {
                let n = book.count(k), gold = book.goldenCount(k)
                let when = k.seasonName.map { " · \($0) only" } ?? ""
                var line = n > 0 ? "\(k.name) · \(k.rarityName) · grown \(n)×" : "??? · \(k.rarityName)\(when)"
                if gold > 0 { line += " · ✨ \(gold) golden" }
                let it = NSMenuItem(title: line, action: nil, keyEquivalent: "")
                it.isEnabled = false
                sbMenu.addItem(it)
            }
        }
        sbMenu.addItem(.separator())
        for text in ["Rare seeds turn up more often during focus sessions", "Some plants only grow in their season, or at night",
                     "Legend says poking a busy gardener can dig something up"] {
            let tip = NSMenuItem(title: text, action: nil, keyEquivalent: "")
            tip.isEnabled = false
            sbMenu.addItem(tip)
        }
        sb.submenu = sbMenu
        more.addItem(.separator())
        more.addItem(sb)
        if world.wishes > 0 {
            let wi = NSMenuItem(title: "✨ A wish is waiting: the next seed will be special", action: nil, keyEquivalent: "")
            wi.isEnabled = false
            more.addItem(wi)
        }
        if book.today > 0 {
            let t = NSMenuItem(title: "Grown today: \(book.today) plant\(book.today == 1 ? "" : "s")", action: nil, keyEquivalent: "")
            t.isEnabled = false
            more.addItem(t)
        }
        let snd = NSMenuItem(title: "Sounds", action: #selector(toggleSounds), keyEquivalent: "")
        snd.target = self
        snd.state = sounds.enabled ? .on : .off
        snd.toolTip = "Tiny chimes when a flower opens on a tree, a fruit ripens, a house joins the village or a gem turns up. Quiet, and never during focus sessions."
        settings.addItem(snd)
        let rem = NSMenuItem(title: "Water & Stretch Reminders", action: #selector(toggleReminders), keyEquivalent: "")
        rem.target = self
        rem.state = remindersOn ? .on : .off
        settings.addItem(rem)
        let cli = NSMenuItem(title: "Copy Terminal Command Setup", action: #selector(copyCLISetup), keyEquivalent: "")
        cli.target = self
        cli.toolTip = "Lets scripts and test runners make your Gremlets react (gremlet pass / fail / done)."
        more.addItem(cli)

        let pause = NSMenuItem(title: paused ? "Resume" : "Pause", action: #selector(togglePause), keyEquivalent: "p")
        pause.target = self
        let hide = NSMenuItem(title: manuallyHidden ? "Show Gremlets" : "Hide Gremlets", action: #selector(toggleHidden), keyEquivalent: "g")
        hide.keyEquivalentModifierMask = [.control, .option]
        hide.target = self
        hide.toolTip = "Works anywhere with ⌃⌥G"
        let calls = NSMenuItem(title: "Hide During Calls", action: #selector(toggleHideDuringCalls), keyEquivalent: "")
        calls.target = self
        calls.state = hideDuringCalls ? .on : .off
        calls.toolTip = "Slip away whenever an app uses your camera or microphone (Zoom, Meet, FaceTime…), so they never end up in a screen share."
        settings.addItem(calls)

        let login = NSMenuItem(title: "Start When I Log In", action: #selector(toggleLogin), keyEquivalent: "")
        login.target = self
        login.state = SMAppService.mainApp.status == .enabled ? .on : .off
        settings.addItem(login)

        let folder = NSMenuItem(title: "Open Custom Sprites Folder…", action: #selector(openSpritesFolder), keyEquivalent: "")
        folder.target = self
        more.addItem(folder)

        let quit = NSMenuItem(title: "Quit Gremlets", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        // Assemble: everyday things, then Settings and More, then pause / hide / quit.
        menu.addItem(.separator())
        settings.addItem(.separator())
        let permHeader = NSMenuItem(title: "Extras that need your permission", action: nil, keyEquivalent: ""); permHeader.isEnabled = false
        settings.addItem(permHeader)
        settings.addItem(ctl)
        let dk = NSMenuItem(title: dock.enabled && !dock.trusted ? "Play on the Dock · allow in System Settings" : "Play on the Dock",
                            action: #selector(toggleDock), keyEquivalent: "")
        dk.target = self
        dk.state = dock.enabled && dock.trusted ? .on : .off
        dk.toolTip = "Gremlets hop across your Dock icons, cheer apps you open (an icon's bounce sends whoever's on it flying), knock on icons with a new badge and nap on the Trash. Uses Accessibility (the same permission as above) to see where the icons are. Nothing is clicked."
        settings.addItem(dk)
        for it in senseItems { settings.addItem(it) }
        let settingsItem = NSMenuItem(title: "Settings", action: nil, keyEquivalent: "")
        settingsItem.submenu = settings
        menu.addItem(settingsItem)
        let focusItem = NSMenuItem(title: focus.label.map { "Focus Timer · \($0) left" } ?? "Focus Timer", action: nil, keyEquivalent: "")
        focusItem.submenu = focusMenu
        more.insertItem(focusItem, at: 0)
        let moreItem = NSMenuItem(title: "More", action: nil, keyEquivalent: "")
        moreItem.submenu = more
        menu.addItem(moreItem)
        menu.addItem(.separator())
        menu.addItem(pause)
        menu.addItem(hide)
        menu.addItem(.separator())
        menu.addItem(quit)
        let items = menu.items
        menu.removeAllItems()
        return items
    }

    @objc private func addCreature(_ sender: NSMenuItem) {
        guard let id = sender.representedObject as? String, let sp = species[id] else { return }
        guard admit(id) else { return }
        // Drop in from the top of the screen the cursor is on.
        let m = NSEvent.mouseLocation
        let scr = NSScreen.screens.first { $0.frame.contains(m) } ?? NSScreen.main
        let vf = scr?.visibleFrame ?? .zero
        let x = min(max(Double(m.x), vf.minX + 60), vf.maxX - 60)
        world.spawn(sp.info, at: Vec2(x, Double(vf.maxY) - sp.info.pointSize.y - 4))
        bonds.markSeenToday(id)
        world.setBond(bonds.bond(id).strength, forSpecies: id)
        saveRoster()
        rebuildMenu()
        schedule(rate: 60)
    }

    func applicationWillTerminate(_ notification: Notification) { bonds.save() }

    @objc private func addRandomParty() {
        var picks: [LoadedSpecies] = []
        var out = world.creatures.map(\.species.id)
        let now = Date().timeIntervalSince1970
        // Yours first, then demos while there's room.
        let pool = species.values.shuffled().sorted { !access.isDemo($0.info.id) && access.isDemo($1.info.id) }
        for sp in pool where picks.count < 5 && access.canAdd(sp.info.id, out: out, now: now) == .ok {
            picks.append(sp); out.append(sp.info.id)
            if access.isDemo(sp.info.id) { access.noteDemoAdded(now: now) }
        }
        if picks.isEmpty { _ = admit(species.values.first { access.isDemo($0.info.id) }?.info.id ?? ""); return }
        let m = NSEvent.mouseLocation
        let vf = (NSScreen.screens.first { $0.frame.contains(m) } ?? NSScreen.main)?.visibleFrame ?? .zero
        for (i, sp) in picks.enumerated() {
            let x = Double(vf.minX) + Double(vf.width) * (0.2 + 0.15 * Double(i))
            world.spawn(sp.info, at: Vec2(x, Double(vf.maxY) - sp.info.pointSize.y - 4))
            bonds.markSeenToday(sp.info.id)
            world.setBond(bonds.bond(sp.info.id).strength, forSpecies: sp.info.id)
        }
        saveRoster()
        rebuildMenu()
        schedule(rate: 60)
    }

    @objc private func removeCreature(_ sender: NSMenuItem) {
        guard let id = sender.representedObject as? Int else { return }
        world.remove(id)
        overlay.render()
        saveRoster()
        rebuildMenu()
    }

    @objc private func togglePause() {
        paused.toggle()
        overlay.paused = paused
        rebuildMenu()
    }

    @objc private func toggleLogin() {
        do {
            if SMAppService.mainApp.status == .enabled { try SMAppService.mainApp.unregister() }
            else { try SMAppService.mainApp.register() }
        } catch {
            let alert = NSAlert()
            alert.messageText = "Couldn't change Launch at Login"
            alert.informativeText = "This works when Gremlets runs from Gremlets.app (not `swift run`).\n\n\(error.localizedDescription)"
            alert.runModal()
        }
        rebuildMenu()
    }

    // MARK: Ownership & demo

    private func setUpAccess() {
        let args = CommandLine.arguments, env = ProcessInfo.processInfo.environment
        let deployment = Deployment.load()
        var policy = DemoPolicy()
        if let s = env["GREMLETS_DEMO_SECONDS"].flatMap(Double.init) { policy.sessionSeconds = s }   // for testing
        // Gating starts once the collection is on testnet (deployment.json present). Until then this is a preview
        // build with everything unlocked. --visitor previews demo mode; --unlock-all is a developer override.
        let gated = (deployment != nil || args.contains("--visitor")) && !args.contains("--unlock-all")
        access = Access(tokens: Resources.tokens(), ownership: args.contains("--visitor") ? Ownership() : OwnershipStore.load(),
                        policy: policy, gatingEnabled: gated)
        guard let deployment, gated else { return }
        let link = WalletLink(deployment: deployment, tokenIDs: access.tokens.keys.sorted())
        link.onOwnership = { [weak self] o in
            guard let self else { return }
            let before = self.access.ownedSpecies
            self.access.ownership = o
            OwnershipStore.save(o)
            let gained = self.access.ownedSpecies.subtracting(before)
            for c in self.world.creatures where gained.contains(c.species.id) { self.overlay.bondLevelUp(c) }  // hearts: it's yours now
            self.rebuildMenu()
        }
        link.onStateChange = { [weak self] in self?.rebuildMenu() }
        wallet = link
        link.refresh(access.ownership)
    }

    /// Checks the demo rules before a Gremlet comes out; explains kindly if it can't.
    private func admit(_ id: String) -> Bool {
        let now = Date().timeIntervalSince1970
        switch access.canAdd(id, out: world.creatures.map(\.species.id), now: now) {
        case .ok:
            if access.isDemo(id) { access.noteDemoAdded(now: now); demoNotice = nil }
            return true
        case .demoFull(let max):
            let alert = NSAlert()
            alert.messageText = "Demo Gremlets: \(max) at a time"
            alert.informativeText = "Send one of your demo Gremlets home to try another.\n\nGremlets you own stay out as long as you like. Link your wallet from the menu bar (Connect Wallet…), or visit all 50 in the web habitat."
            alert.runModal()
        case .cooldown(let left):
            let alert = NSAlert()
            alert.messageText = "The demo Gremlets are resting"
            alert.informativeText = "You can start another demo in \(Int(left / 60) + 1) min."
            alert.runModal()
        }
        return false
    }

    /// Demo time's up: each demo Gremlet waves goodbye, then heads home.
    private func endDemoSession() {
        let leaving = world.creatures.filter { access.isDemo($0.species.id) }.map(\.id)
        guard !leaving.isEmpty else { return }
        for id in leaving { world.sayGoodbye(id) }
        schedule(rate: 60)
        demoNotice = "Demo over: they waved goodbye. Start another any time."
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) { [weak self] in
            guard let self else { return }
            for id in leaving where self.world.creatures.contains(where: { $0.id == id && self.access.isDemo($0.species.id) }) {
                self.world.remove(id)
            }
            self.overlay.render()
            self.saveRoster()
            self.rebuildMenu()
        }
    }

    private func walletMenuItems() -> [NSMenuItem] {
        var items: [NSMenuItem] = []
        func info(_ t: String) { let i = NSMenuItem(title: t, action: nil, keyEquivalent: ""); i.isEnabled = false; items.append(i) }
        func action(_ t: String, _ sel: Selector) { let i = NSMenuItem(title: t, action: sel, keyEquivalent: ""); i.target = self; items.append(i) }

        guard access.gatingEnabled else {
            info("Preview build: all Gremlets unlocked")
            return items
        }
        let now = Date().timeIntervalSince1970
        if let left = access.secondsLeft(now: now) {
            let demoOut = world.creatures.filter { access.isDemo($0.species.id) }.count
            info(String(format: "Demo: %d:%02d left · %d/%d out", Int(left) / 60, Int(left) % 60, demoOut, access.policy.maxOut))
        } else if let n = demoNotice {
            info(n)
        }
        if let addr = access.ownership.address {
            let n = access.ownedSpecies.count
            info("Wallet \(Ethereum.shortAddress(addr)) · owns \(n) Gremlet\(n == 1 ? "" : "s")")
            if wallet != nil { action("Check Ownership Again", #selector(recheckOwnership)) }
            action("Unlink Wallet", #selector(unlinkWallet))
        } else if wallet != nil {
            action("Connect Wallet…", #selector(connectWallet))
            items.last?.toolTip = "Prove you hold Gremlets with a free signature in your browser wallet. No transaction, no seed phrase."
        } else {
            info("Visitor preview (no collection configured)")
        }
        switch wallet?.state {
        case .waiting?: info("Waiting for your browser wallet…")
        case .checking?: info("Checking ownership on Base Sepolia…")
        case .failed(let m)?: info(m)
        default: break
        }
        return items
    }

    @objc private func connectWallet() { wallet?.begin() }

    @objc private func recheckOwnership() { wallet?.refresh(access.ownership, force: true) }

    @objc private func unlinkWallet() {
        access.ownership = Ownership()
        OwnershipStore.save(access.ownership)
        // Anything that was yours is now a demo; trim to the demo limit right away.
        let demos = world.creatures.filter { access.isDemo($0.species.id) }
        for c in demos.dropFirst(access.policy.maxOut) { world.remove(c.id) }
        if !demos.isEmpty { access.noteDemoAdded(now: Date().timeIntervalSince1970) }
        overlay.render()
        saveRoster()
        rebuildMenu()
    }

    // MARK: Companion

    private func setUpCompanion() {
        for c in world.creatures {
            bonds.markSeenToday(c.species.id)
            world.setBond(bonds.bond(c.species.id).strength, forSpecies: c.species.id)
        }
        bonds.save()
        focus.onFocusStart = { [weak self] in self?.world.focusMode = true; self?.rebuildMenu() }
        focus.onBreakStart = { [weak self] in
            guard let self else { return }
            // A finished session: log it, and every Gremlet that kept you company grows a little closer.
            self.focusLog.record(minutes: self.focus.focusMinutes)
            for id in Set(self.world.creatures.map(\.species.id)) {
                let before = self.bonds.bond(id).level
                self.bonds.addFocusSession(id)
                let after = self.bonds.bond(id)
                if after.level > before, let c = self.world.creatures.first(where: { $0.species.id == id }) {
                    self.world.setBond(after.strength, forSpecies: id); self.overlay.bondLevelUp(c)
                }
            }
            self.bonds.save()
            self.world.receive(.pass); self.schedule(rate: 60); self.rebuildMenu()
        }
        focus.onBreakEnd = { [weak self] in self?.world.receive(.done); self?.rebuildMenu() }
        let server = ControlServer { [weak self] method, path, query in
            guard let self else { return (404, "{}") }
            return self.handleControl(method: method, path: path, query: query)
        }
        server.pages["/connect"] = { [weak self] in self?.wallet?.page() ?? "<p>Wallet linking isn't set up in this build.</p>" }
        server.pages["/pair"] = { [weak self] in self?.phone.pairPage() ?? "" }
        server.pages["/link"] = { [weak self] in self?.bridge.linkPage() ?? "" }
        server.pages["/terrarium"] = { [weak self] in self?.bridge.linkPage(terrarium: true) ?? "" }
        server.pages["/chat"] = { [weak self] in self?.chatPage() ?? "" }
        server.pages["/scrapbook"] = { [weak self] in self.map { Scrapbook.page(log: $0.dayLog) } ?? "" }
        server.pages["/journal"] = { [weak self] in
            guard let self else { return "" }
            return Journal.page(world: self.world, species: self.species, log: self.dayLog, sessions: self.buddy.sessionLog.recent)
        }
        overlay.onDoubleClick = { [weak self] id in self?.sayHello(id) }
        overlay.onRightClick = { [weak self] id in self?.showAskMenu(id) }
        world.questBoard = nil
        // The Dock: icons to hop on, apps opening and quitting, badges.
        dock.onChange = { [weak self] icons in self?.world.dockIcons = icons }
        dock.onOpened = { [weak self] app in self?.world.dockAppOpened(app); self?.schedule(rate: 60) }
        dock.onQuit = { [weak self] app in self?.world.dockAppQuit(app); self?.schedule(rate: 60) }
        dock.onBadge = { [weak self] app in self?.world.dockBadgeAppeared(app); self?.schedule(rate: 60) }
        overlay.icons = icons
        icons.onChange = { [weak self] in self?.rebuildMenu() }
        icons.refresh()
        phone.onArrive = { [weak self] arrival in self?.arriveFromPhone(arrival) }
        phone.onStatus = { [weak self] in self?.rebuildMenu() }
        bridge.onWalk = { [weak self] w in self?.arriveThroughBridge(w) }
        bridge.moss = { [weak self] in Int(self?.world.mossMinutes ?? 0) }
        bridge.onFerry = { [weak self] riders, y in self?.ferryArrivesThroughBridge(riders: riders, yFrac: y) }
        bridge.onStatus = { [weak self] in self?.updateDoor(); self?.rebuildMenu() }
        bridge.status = { [weak self] in self.map { $0.terrariumBoard.snapshot(showNames: $0.terrariumNames).json() } }
        bridge.start()
        weatherService.onChange = { [weak self] in self?.schedule(rate: 60); self?.rebuildMenu() }
        weatherService.restart()
        netMonitor.pathUpdateHandler = { [weak self] path in
            DispatchQueue.main.async {
                guard let self else { return }
                let now = path.status == .satisfied
                if let was = self.online, was != now { self.world.machineSignal(now ? .online : .offline); self.schedule(rate: 60) }
                self.online = now
            }
        }
        netMonitor.start(queue: DispatchQueue(label: "gremlets.net"))
        if phone.isPaired { phone.start() }
        server.start()
        control = server
        // Boss key: ⌃⌥G hides/shows every Gremlet instantly.
        hideHotKey = HotKey(keyCode: kVK_ANSI_G, modifiers: controlKey | optionKey, id: 1) { [weak self] in self?.toggleHidden() }
        if CommandLine.arguments.contains("--focus-demo") { focus.breakMinutes = 0.25; focus.startFocus(minutes: 0.25) }
    }

    private func handleControl(method: String, path: String, query: [String: String]) -> (Int, String) {
        let name = path.trimmingCharacters(in: CharacterSet(charactersIn: "/")).lowercased()
        if name == "wallet/test-begin", method == "POST", ProcessInfo.processInfo.environment["GREMLETS_WALLET_TEST"] == "1", let w = wallet {
            return (200, w.beginForTest())
        }
        if name == "wallet/status" { return (200, wallet?.statusJSON() ?? #"{"state":"idle"}"#) }
        if name == "wallet/proof" {
            guard method == "POST" else { return (405, #"{"ok":false,"error":"use POST"}"#) }
            return wallet?.handleProof(query) ?? (404, #"{"ok":false,"error":"wallet linking isn't set up in this build"}"#)
        }
        if name == "mcp" {
            return handleMCP(query)
        }
        if name == "status" {
            let ids = world.creatures.map { "\"\($0.species.id)\"" }.joined(separator: ",")
            let primaryTop = Double(NSScreen.screens.first?.frame.maxY ?? 0)
            let busy = world.creatures.compactMap { c -> String? in
                guard let j = c.job else { return nil }
                // Top-left based screen coordinates, the same as `screencapture -R`.
                return #"{"gremlet":"\#(c.species.id)","craft":"\#(j.craft.rawValue)","shelf":\#(j.shelfSide != nil),"x":\#(Int(c.pos.x)),"y":\#(Int(primaryTop - c.pos.y))}"#
            }.joined(separator: ",")
            let f = focus.label.map { "\"\($0)\"" } ?? "null"
            let h = presence.hidden.map { "\"\($0.rawValue)\"" } ?? "null"
            let jobs = world.creatures.compactMap { c -> String? in
                guard let j = c.job, j.kind == .claude else { return nil }
                return #"{"gremlet":"\#(c.species.id)","phase":"\#(j.phase)","blocks":\#(j.blocks),"work":\#(Int(j.workSeconds)),"window":\#(j.windowID.map(String.init) ?? "null"),"side":\#(j.shelfSide.map { String(Int($0)) } ?? "null"),"label":"\#(j.label ?? "")"}"#
            }.joined(separator: ",")
            let trees = world.bonsaiPlacements.map { #"{"project":"\#($0.project)","slot":\#($0.slot),"window":\#($0.windowID.map(String.init) ?? "null"),"x":\#(Int($0.base.x)),"y":\#(Int($0.base.y)),"scale":\#($0.scale)}"# }.joined(separator: ",")
            // Expeditions underway (legs done / planned, the current move), chests and what's been built.
            let runs = world.creatures.compactMap { c -> String? in
                guard let ex = c.expedition else { return nil }
                let goal: String = { if case .treasure(let id) = ex.goal { return "chest \(id)" }; return "summit" }()
                return #"{"gremlet":"\#(c.species.id)","goal":"\#(goal)","phase":"\#(ex.phase)","leg":\#(ex.index),"legs":[\#(ex.methods.map { "\"\($0.rawValue)\"" }.joined(separator: ","))],"x":\#(Int(c.pos.x)),"y":\#(Int(primaryTop - c.pos.y)),"activity":"\#(c.activity)"}"#
            }.joined(separator: ",")
            let who = world.creatures.map { c -> String in
                #"{"id":\#(c.id),"species":"\#(c.species.id)","activity":"\#(c.activity)","grounded":\#(c.isGrounded),"x":\#(Int(c.pos.x)),"y":\#(Int(primaryTop - c.pos.y)),"job":\#(c.job != nil),"home":\#(c.homeUntil != nil),"ground":\#(c.groundOwner.map(String.init) ?? "null")}"#
            }.joined(separator: ",")
            let chests = world.chests.map { #"{"id":\#($0.id),"x":\#(Int($0.pos.x)),"y":\#(Int(primaryTop - $0.pos.y)),"golden":\#($0.golden),"carriedBy":\#($0.carriedBy.map(String.init) ?? "null")}"# }.joined(separator: ",")
            return (200, #"{"ok":true,"gremlets":[\#(ids)],"focus":\#(f),"paused":\#(paused),"hidden":\#(h),"away":\#(presence.isAway),"focusToday":\#(Int(focusLog.todayMinutes)),"streak":\#(focusLog.streak),"busy":[\#(busy)],"claude":[\#(jobs)],"ledges":\#(world.terminalLedges.count),"trees":[\#(trees)],"expeditions":[\#(runs)],"chests":[\#(chests)],"who":[\#(who)],"door":\#(world.door.map { String(Int($0)) } ?? "null"),"flags":\#(world.flags.count),"ziplines":\#(world.ziplines.count),"stairs":\#(world.stairs.count),"rails":\#(world.rails.count),"widgets":\#(world.widgetIDs.count),"pantry":\#(world.pantry),"care":\#(world.homeCare),"houseStage":\#(world.houseStage),"birds":\#(world.birds.count),"critters":\#(world.critters.count),"ownDay":\#(world.ownDay),"barrel":\#((world.rainBarrel * 100).rounded() / 100),"patch":"\#(world.patchSaved)","mail":\#(world.mailbox.count),"unread":\#(world.unreadMail),"mailOpen":\#(world.mailOpen),"lanterns":\#(world.mossLanterns.count),"seeds":"\#(world.seedTinSaved)","leaves":\#((world.porchLeaves * 100).rounded() / 100),"snow":\#((world.roofSnow * 100).rounded() / 100),"jar":\#(world.fireflyJar),"hive":\#(world.hasHive),"basket":\#(world.basket.map { "\"\($0.phase)\"" } ?? "null"),"basketLanding":\#(world.basketLanding().map { String(Int($0.y)) } ?? "null"),"ax":\#(AXIsProcessTrusted()),"menuBar":[\#(world.menuBars.map { b in b.map { b in "[" + b.clear.map { "[\(Int($0.lo)),\(Int($0.hi))]" }.joined(separator: ",") + "]" } ?? "null" }.joined(separator: ","))],"topWalks":[\#(world.surfaces.filter { t in t.kind == .windowTop && t.y > (world.screens.first?.maxY ?? .infinity) - 40 }.map { "[\(Int($0.minX)),\(Int($0.maxX)),\(Int($0.y))]" }.joined(separator: ","))]}"#)
        }
        guard method == "POST" else { return (405, #"{"ok":false,"error":"use POST"}"#) }
        switch name {
        case "focus":
            let minutes = Double(query["minutes"] ?? "") ?? 25
            focus.startFocus(minutes: min(max(minutes, 1), 180))
        case "hide", "show":
            manuallyHidden = name == "hide"
            updatePresence()
            return (200, #"{"ok":true}"#)
        case "unfocus":
            focus.stop(); world.focusMode = false; rebuildMenu()
        case "chat/state":
            return (200, chatState(query["name"]))
        case "chat/send":
            guard let c = chatTarget(query["name"]), let raw = query["_body"]?.trimmingCharacters(in: .whitespacesAndNewlines), !raw.isEmpty else {
                return (400, #"{"ok":false,"error":"say something"}"#)
            }
            sendChat(String(raw.prefix(800)), to: c)
            return (202, #"{"ok":true,"pending":true}"#)
        case "chat/key":
            companion.setKey(query["_body"]?.trimmingCharacters(in: .whitespacesAndNewlines))
            return (200, #"{"ok":true,"ai":\#(companion.hasKey)}"#)
        case "chat/nick":
            guard let c = chatTarget(query["name"]) else { return (404, "{}") }
            companion.setNickname(c.species.id, query["_body"])
            rebuildMenu()
            return (200, #"{"ok":true}"#)
        case "chat/me":
            companion.userName = query["_body"].map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            return (200, #"{"ok":true}"#)
        case "chat/forget":
            if let c = chatTarget(query["name"]) { companion.forget(c.species.id) }
            return (200, #"{"ok":true}"#)
        case "phone/pair":
            phone.pair()
            rebuildMenu()
            return (200, #"{"ok":true,"url":"\#(phone.pairURL ?? "")"}"#)
        case "phone/send":
            guard phone.isPaired else { return (409, #"{"ok":false,"error":"not paired: run gremlet pair first"}"#) }
            let want = (query["name"] ?? "").lowercased()
            guard let c = world.creatures.first(where: { $0.species.id == want || $0.species.name.lowercased() == want }) ?? (want.isEmpty ? world.creatures.first : nil) else {
                return (404, #"{"ok":false,"error":"no Gremlet by that name is out"}"#)
            }
            let item = NSMenuItem(); item.representedObject = c.id
            sendToPhone(item)
            return (200, #"{"ok":true}"#)
        case "event":
            guard let k = SpectacleKind(rawValue: query["kind"] ?? "") else { return (400, #"{"ok":false,"error":"kind must be meteors, festival or lanterns"}"#) }
            guard world.startEvent(k) else { return (409, #"{"ok":false,"error":"an event is already running"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "demo":
            // A scripted Claude session on the front window; the reply names the screen region worth recording.
            let seconds = min(120, max(20, Double(query["seconds"] ?? "") ?? 42))
            let pid = query["pid"].flatMap { Int32($0) }
            guard let r = showcase.start(seconds: seconds, pid: pid) else {
                return (409, #"{"ok":false,"error":"no front window with room above it (or a demo is already running)"}"#)
            }
            schedule(rate: 60)
            return (200, #"{"ok":true,"seconds":\#(Int(seconds)),"region":"\#(Int(r.minX)),\#(Int(r.minY)),\#(Int(r.width)),\#(Int(r.height))"}"#)
        case "season":
            let names = ["winter": 1, "spring": 4, "summer": 7, "autumn": 10, "fall": 10]
            let arg = (query["name"] ?? "auto").lowercased()
            if arg == "auto" { seasonOverride = nil } else if let m = names[arg] ?? Int(arg), (1...12).contains(m) { seasonOverride = (m, Date().addingTimeInterval(600)) }
            else { return (400, #"{"ok":false,"error":"season must be winter, spring, summer, autumn, a month number or auto"}"#) }
            housekeeping(elapsed: 0); overlay.fx.rebuild(); overlay.bonsaiFX.rebuild(); schedule(rate: 60)
            return (200, #"{"ok":true,"month":\#(world.month)}"#)
        case "night":
            let arg = (query["on"] ?? "auto").lowercased()
            if arg == "auto" { nightOverride = nil } else { nightOverride = (["on", "1", "true", "yes"].contains(arg), Date().addingTimeInterval(600)) }
            housekeeping(elapsed: 0); overlay.fx.rebuild(); overlay.bonsaiFX.rebuild(); schedule(rate: 60)
            return (200, #"{"ok":true,"night":\#(world.isNight)}"#)
        case "gif":
            // A looping GIF of a recording (the demo), for a README or a post.
            let path = Self.decoded(query["path"] ?? "")
            guard path.hasPrefix(FileManager.default.homeDirectoryForCurrentUser.path), FileManager.default.fileExists(atPath: path) else {
                return (400, #"{"ok":false,"error":"path must be a recording in your home folder"}"#)
            }
            guard let url = GIFMaker.make(from: URL(fileURLWithPath: path)) else { return (500, #"{"ok":false,"error":"couldn't read that recording"}"#) }
            return (200, #"{"ok":true,"path":"\#(url.path)"}"#)
        case "timelapse":
            TimeLapse.saveToday(world: world, species: species)
            if let project = query["project"].map(Self.decoded), !project.isEmpty {
                guard let url = TimeLapse.treeGIF(project: project) else { return (404, #"{"ok":false,"error":"no daily pictures of that tree yet"}"#) }
                return (200, #"{"ok":true,"path":"\#(url.path)"}"#)
            }
            guard let url = TimeLapse.build() else { return (404, #"{"ok":false,"error":"no daily postcards yet"}"#) }
            return (200, #"{"ok":true,"path":"\#(url.path)"}"#)
        case "recap":
            let name = Self.decoded(query["project"] ?? "")
            if query["sample"] == "1" {
                let (r, after) = SessionRecord.sample()
                guard let url = SessionRecapCard.make(r, after: after, world: world, copy: true) else { return (500, #"{"ok":false}"#) }
                return (200, #"{"ok":true,"path":"\#(url.path)"}"#)
            }
            guard let r = buddy.sessionLog.last(project: name) else { return (404, #"{"ok":false,"error":"no finished Claude sessions yet (try gremlet recap --sample)"}"#) }
            guard let url = SessionRecapCard.make(r, after: world.bonsaiBook[r.project], world: world, copy: true) else { return (500, #"{"ok":false}"#) }
            return (200, #"{"ok":true,"path":"\#(url.path)"}"#)
        case "forest":
            guard let url = ForestPoster.make(world: world, species: species) else { return (404, #"{"ok":false,"error":"no trees yet"}"#) }
            return (200, #"{"ok":true,"path":"\#(url.path)"}"#)
        case "card":
            let name = Self.decoded(query["project"] ?? "")
            guard let t = name.isEmpty ? world.bonsaiBook.trees.max(by: { $0.lastSeen < $1.lastSeen }) : world.bonsaiBook[name] else {
                return (404, #"{"ok":false,"error":"no tree for that project"}"#)
            }
            guard let url = TreeCard.make(t, world: world) else { return (500, #"{"ok":false}"#) }
            return (200, #"{"ok":true,"path":"\#(url.path)"}"#)
        case "kite":
            guard world.startKiteWithAnyone() else {
                return (409, #"{"ok":false,"error":"nobody free to fly one right now"}"#)
            }
            return (200, #"{"ok":true}"#)
        case "postcard":
            // A sample postcard in the mailbox (what a session finishing while you're away leaves).
            guard world.mailboxSpot != nil else { return (409, #"{"ok":false,"error":"no hanging home showing"}"#) }
            world.post(Postcard(project: query["project"] ?? "Gremlets", text: query["text"] ?? "48 min · 31 edits · 3 tasks done · tests passing", at: Date().timeIntervalSince1970))
            saveMoss()
            schedule(rate: 60)
            return (200, #"{"ok":true,"unread":\#(world.unreadMail)}"#)
        case "patch":
            // Sow the vegetable patch now (ripe=1: ready to pick).
            guard world.sowPatchNow(ripe: query["ripe"] == "1") else { return (409, #"{"ok":false,"error":"the nest hut isn't out (full screen, or widgets in both top corners)"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true,"patch":"\#(world.patchSaved)"}"#)
        case "porch":
            // Pile up autumn leaves or snow on the nest hut now (to try the sweeping), or clear them.
            switch query["what"] ?? "leaves" {
            case "snow": world.roofSnow = 1
            case "clear": world.roofSnow = 0; world.porchLeaves = 0
            default: world.porchLeaves = 1
            }
            schedule(rate: 60)
            return (200, #"{"ok":true,"leaves":\#(world.porchLeaves),"snow":\#(world.roofSnow)}"#)
        case "jar":
            // Fireflies in the jar now.
            world.fireflyJar = World.jarMax
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "seeds":
            // Seeds from a friend for the patch now.
            guard let crop = world.newFriendCrop, world.receiveSeeds(crop, by: world.say()) else { return (409, #"{"ok":false,"error":"the seed tin has every kind already"}"#) }
            saveMoss()
            return (200, #"{"ok":true,"seeds":"\#(world.seedTinSaved)"}"#)
        case "morningcard":
            // Yesterday's postcard in the mailbox now.
            guard postMorningCard(force: true) else { return (409, #"{"ok":false,"error":"nothing to tell about yesterday"}"#) }
            return (200, #"{"ok":true}"#)
        case "lanterns":
            // Someone sets a lantern out on the moss now.
            guard world.hangLanternNow() else { return (409, #"{"ok":false,"error":"nobody free on a window top"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "bird":
            // A bird drops by now.
            guard world.spawnBird() else { return (409, #"{"ok":false,"error":"one's already here"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "nudge":
            guard world.nudgeHome() else { return (409, #"{"ok":false,"error":"no hanging home showing (or just nudged)"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "pantry":
            if let n = query["n"].flatMap(Int.init) { world.pantry = max(0, min(World.pantryMax, n)); saveMoss() }
            if let n = query["care"].flatMap(Int.init) { world.homeCare = max(0, n); saveMoss() }
            return (200, #"{"ok":true,"pantry":\#(world.pantry),"care":\#(world.homeCare),"stage":\#(world.houseStage)}"#)
        case "ask":
            // gremlet ask <idea> [name]: what the right-click menu does (no idea: lists what each could do).
            let pool = world.creatures.filter { c in query["name"].map { $0.isEmpty || c.species.id == $0 || c.species.name.lowercased() == $0.lowercased() } ?? true }
            guard let raw = query["idea"], !raw.isEmpty else {
                let list = pool.map { c in #"{"gremlet":"\#(c.species.id)","ideas":[\#(world.ideas(for: c).map { "\"\($0.rawValue)\"" }.joined(separator: ","))]}"# }
                return (200, "[\(list.joined(separator: ","))]")
            }
            guard let idea = Idea(rawValue: raw) else { return (400, #"{"ok":false,"error":"unknown idea"}"#) }
            guard let c = pool.first(where: { world.ideas(for: $0).contains(idea) }), world.ask(c, idea) else {
                return (409, #"{"ok":false,"error":"nobody can do that from where they are right now"}"#)
            }
            overlay.ecoFX.handle(world.drainEcoEvents())
            schedule(rate: 60)
            return (200, #"{"ok":true,"gremlet":"\#(c.species.id)"}"#)
        case "stairs":
            guard world.startStairsWithAnyone() else {
                return (409, #"{"ok":false,"error":"nowhere to build up to: a Gremlet standing on a floor or window needs another window's top 90 to 480 points above it, with room beside it"}"#)
            }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "link":
            let side = (query["side"] == "left") ? "left" : "right"
            let hab = Self.decoded(query["habitat"] ?? "")
            if !hab.isEmpty { bridge.habitat = hab }
            if !bridge.linked || bridge.side != side { bridge.create(side: side) }
            updateDoor(); rebuildMenu()
            return (200, #"{"ok":true,"url":"\#(bridge.inviteURL ?? "")","side":"\#(side)"}"#)
        case "unlink":
            bridge.unlink(); updateDoor(); rebuildMenu()
            return (200, #"{"ok":true}"#)
        case "moss":
            // Preview the overgrowth at a number of minutes of Claude work (0 clears it), or set someone to work on it.
            if let what = query["do"] {
                guard world.startMossActivity(what) else { return (409, #"{"ok":false,"error":"nobody free near moss for that (climb needs vines: 40+ minutes of moss)"}"#) }
                schedule(rate: 60)
                return (200, #"{"ok":true}"#)
            }
            if let v = query["minutes"].flatMap(Double.init) { world.mossMinutes = v.clamped(0, World.mossMax); saveMoss() }
            schedule(rate: 60)
            return (200, #"{"ok":true,"minutes":\#(Int(world.mossMinutes)),"care":\#(Int(world.mossCare * 100))}"#)
        case "picnic":
            guard world.startPicnic() else { return (409, #"{"ok":false,"error":"no one free for a picnic"}"#) }
            schedule(rate: 60); return (200, #"{"ok":true}"#)
        case "blanket":
            guard world.bringBlanket(towardX: Double(NSEvent.mouseLocation.x)) else { return (409, #"{"ok":false,"error":"no one free"}"#) }
            schedule(rate: 60); return (200, #"{"ok":true}"#)
        case "friendseed":
            guard world.friendSeed(tint: 0x8FD3FF) else { return (409, #"{"ok":false,"error":"no window top to grow on"}"#) }
            schedule(rate: 60); return (200, #"{"ok":true}"#)
        case "stretch":
            world.stretchBreak(); schedule(rate: 60); return (200, #"{"ok":true}"#)
        case "critters":
            // A ladybug, a bee and a little snail come out onto the moss now.
            let n = world.crittersNow()
            guard n > 0 else { return (409, #"{"ok":false,"error":"no window top for them"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true,"critters":\#(n)}"#)
        case "dock":
            // Someone hops along the Dock now (needs Play on the Dock + Accessibility).
            guard world.dockHopNow() else {
                return (409, dock.trusted ? #"{"ok":false,"error":"no Dock icons along the bottom (hidden, on a side, or full screen)"}"# : #"{"ok":false,"error":"allow Gremlets in System Settings > Privacy & Security > Accessibility"}"#)
            }
            schedule(rate: 60)
            return (200, #"{"ok":true,"icons":\#(world.dockIcons.count)}"#)
        case "fireflies":
            // A few fireflies come out over the moss now (night or not) for a couple of minutes.
            guard world.firefliesNow() else { return (409, #"{"ok":false,"error":"no moss or window top for them"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "quest":
            // gremlet quest [done N | undo N | add TEXT | remove N]: the list only (the corner board is gone).
            switch query["do"] ?? "" {
            case "done": if let n = query["n"].flatMap(Int.init) { quests.setDone(n, true) }
            case "undo": if let n = query["n"].flatMap(Int.init) { quests.setDone(n, false) }
            case "add": quests.add(Self.decoded(query["text"] ?? ""))
            case "remove": if let n = query["n"].flatMap(Int.init) { quests.remove(n) }
            default: break
            }
            let list = quests.steps.enumerated().map { i, st in "\(st.done ? "[x]" : "[ ]") \(i + 1). \(st.text)" }.joined(separator: "\n")
            return (200, list + "\n")
        case "sprout":
            // Something ready to pick comes up in the moss on a window top (daisy, mushroom, berries, dandelion).
            let kind = query["kind"].flatMap { MossSprout.Kind(rawValue: $0) }
            guard world.sproutNow(kind) else { return (409, #"{"ok":false,"error":"no window top to grow on"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "weather":
            // Preview a sky for two minutes (rain, drizzle, storm, snow, wind, clear), start a snow-Gremlet, or set the city.
            if let city = query["city"].map(Self.decoded), !city.isEmpty {
                weatherService.setCity(city) { [weak self] _ in self?.rebuildMenu() }
                return (202, #"{"ok":true,"looking_up":true}"#)
            }
            if query["do"] == "snowman" {
                guard world.startSnowmanNow() else { return (409, #"{"ok":false,"error":"nobody free on the floor right now"}"#) }
                schedule(rate: 60)
                return (200, #"{"ok":true}"#)
            }
            if let s = query["sky"] {
                if s == "live" { world.setWeather(nil, previewSeconds: 0) }
                else if s == "wind" { world.setWeather(LocalWeather(sky: .clear, windKmh: 35, place: "preview"), previewSeconds: 120) }
                else if let sky = Sky(rawValue: s) { world.setWeather(LocalWeather(sky: sky, windKmh: sky == .storm ? 30 : 8, tempC: sky == .snow ? -2 : 10, place: "preview"), previewSeconds: 120) }
                else { return (400, #"{"ok":false,"error":"sky is one of clear, cloudy, fog, drizzle, rain, storm, snow, wind, live"}"#) }
                schedule(rate: 60)
            }
            let w = world.weather
            return (200, #"{"ok":true,"sky":"\#(w?.sky.rawValue ?? "off")","wind_kmh":\#(Int(w?.windKmh ?? 0)),"snow":\#(Int(world.snowDepth * 100)),"snowmen":\#(world.snowmen.count),"place":"\#(weatherService.place?.name ?? "")"}"#)
        case "boost":
            guard world.startBoostWithAnyone() else { return (409, #"{"ok":false,"error":"no pair free near a window just out of jumping reach"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "react":
            // Demo the reactions to the Mac without waiting for them: screenshot, battery, plugged, offline, online.
            let sig: MachineSignal?
            switch query["name"] ?? "" {
            case "screenshot": sig = .screenshot
            case "battery": sig = .batteryLow(percent: 9)
            case "plugged": sig = .pluggedIn
            case "offline": sig = .offline
            case "online": sig = .online
            default: sig = nil
            }
            guard let sig else { return (400, #"{"ok":false,"error":"name must be screenshot, battery, plugged, offline or online"}"#) }
            world.machineSignal(sig)
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "cross":
            guard world.door != nil else { return (409, #"{"ok":false,"error":"no doorway: link another screen first (gremlet link) and open the link there"}"#) }
            guard world.sendThroughDoor() else { return (409, #"{"ok":false,"error":"nobody free to go over right now"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "expedition":
            guard world.startExpeditionWithAnyone(.summit) else {
                return (409, #"{"ok":false,"error":"no route up: nobody free, or nothing standable high enough above them"}"#)
            }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "chest":
            guard let id = world.spawnChest() else {
                return (409, #"{"ok":false,"error":"nowhere to hide a chest: it needs a window top or ledge 220 points or more above the floor"}"#)
            }
            let going = world.startExpeditionWithAnyone(.treasure(id))
            schedule(rate: 60)
            return (200, #"{"ok":true,"chest":\#(id),"expedition":\#(going)}"#)
        case "cart":
            guard world.startRailWithAnyone() else {
                return (409, #"{"ok":false,"error":"no window wide enough for a rail (420 points or more along the top, with nobody free)"}"#)
            }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "wrapped":
            let m: WrappedPoster.Month
            if query["sample"] == "1" {
                m = WrappedPoster.sample()
            } else {
                let parts = Self.decoded(query["month"] ?? "").split(separator: "-").compactMap { Int($0) }
                let c = Calendar.current.dateComponents([.year, .month], from: Date())
                let (y, mo) = parts.count == 2 && (1...12).contains(parts[1]) ? (parts[0], parts[1]) : (c.year ?? 2026, c.month ?? 1)
                m = WrappedPoster.gather(year: y, month: mo, world: world, log: dayLog, sessions: buddy.sessionLog.recent)
                if m.edits == 0 && m.tasks == 0 { return (404, #"{"ok":false,"error":"nothing logged for that month yet (try gremlet wrapped --sample)"}"#) }
            }
            guard let url = WrappedPoster.make(m, world: world) else { return (500, #"{"ok":false}"#) }
            return (200, #"{"ok":true,"path":"\#(url.path)"}"#)
        case "plant":
            world.rotateGroveNow()
            schedule(rate: 60)
            let k = world.grove.featured.flatMap { $0 >= 0 ? world.grove.plants[$0].kind.rawValue : nil } ?? "none"
            return (200, #"{"ok":true,"plant":"\#(k)"}"#)
        case "compact":
            // Preview full-screen mode for 30 seconds (it follows the real full-screen state after that).
            compactPreviewUntil = query["off"] == nil ? CACurrentMediaTime() + 30 : 0
            refreshEnvironment()
            schedule(rate: 60)
            return (200, #"{"ok":true,"compact":\#(world.compact)}"#)
        case "notch":
            guard world.notchHomeShowing else { return (409, #"{"ok":false,"error":"a window is in the space under the notch, so the home is tucked away"}"#) }
            guard world.startNotchTrip() else { return (409, #"{"ok":false,"error":"nobody can find a way up right now (it needs windows reaching up toward the top of the screen)"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "village-page":
            // A static page of the village to put online (default: ~/Pictures/Gremlets/Village Page).
            let raw = query["dir"].map(Self.decoded) ?? ""
            let dir = raw.isEmpty ? FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Pictures/Gremlets/Village Page", isDirectory: true)
                : URL(fileURLWithPath: (raw as NSString).expandingTildeInPath, isDirectory: true)
            do {
                let url = try VillagePage.write(to: dir, world: world, species: species)
                return (200, #"{"ok":true,"path":"\#(url.path)"}"#)
            } catch {
                return (500, #"{"ok":false,"error":"couldn't write the page there"}"#)
            }
        case "snapshot":
            guard let url = VillageSnapshot.make(world: world, species: species) else { return (500, #"{"ok":false}"#) }
            return (200, #"{"ok":true,"path":"\#(url.path)"}"#)
        case "merchant":
            guard world.callMerchant() else { return (409, #"{"ok":false,"error":"the merchant is already here"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "ferry":
            if query["cross"] != nil {
                guard world.sendFerryThroughDoor() else { return (409, #"{"ok":false,"error":"no screen linked and open (gremlet link), or the ferry is already leaving"}"#) }
                schedule(rate: 60)
                return (200, #"{"ok":true}"#)
            }
            guard world.callFerry() else { return (409, #"{"ok":false,"error":"the ferry is already out, or there's no high window to dock at"}"#) }
            schedule(rate: 60)
            return (200, #"{"ok":true}"#)
        case "grove/feed":
            let n = min(50, max(1, Int(query["tasks"] ?? "") ?? 1))
            for _ in 0..<n { world.feedGrove() }
            saveGrove()
            return (200, #"{"ok":true,"tasks":\#(world.grove.tasks)}"#)
        case "wish":   // shh: a little easter egg, not in the help text
            wishOnAStar()
            return (200, #"{"ok":true,"wish":"granted"}"#)
        case "hobby":
            let craft = query["craft"].flatMap { Craft(rawValue: $0) }
            let shelf: Bool? = query["shelf"].map { $0 == "1" }
            let style = query["style"].flatMap { ShelfStyle(rawValue: $0) }
            guard world.startHobbyNearCursor(craft: craft, onWindow: shelf, style: style) else {
                return (409, #"{"ok":false,"error":"no free Gremlet on the floor or a window"}"#)
            }
        case "claude":
            UserDefaults.standard.set(Date().timeIntervalSince1970, forKey: "claude.lastSeen")
            world.claudeAround = true
            let r = buddy.handle(query)
            schedule(rate: 60)
            return r
        case "say":
            guard let text = SpeechText.clean(query["text"]) else { return (400, #"{"ok":false,"error":"text is required"}"#) }
            let seconds = min(max(Double(query["seconds"] ?? "") ?? 8, 2), 60)
            guard let id = world.say() else { return (409, #"{"ok":false,"error":"no Gremlets are out"}"#) }
            overlay.handle(world.drainEvents())
            overlay.render()
            overlay.showBubble(text, on: id, seconds: seconds)
        default:
            guard let signal = Signal(rawValue: name) else { return (404, #"{"ok":false,"error":"unknown action"}"#) }
            world.receive(signal)
        }
        schedule(rate: 60)
        return (200, #"{"ok":true}"#)
    }

    /// Bond bookkeeping from world events; celebrates when a bond levels up.
    private func trackBond(_ events: [WorldEvent]) {
        for e in events {
            let id: Int, petted: Bool
            switch e {
            case .petted(let i): id = i; petted = true
            case .poked(let i): id = i; petted = false
            default: continue
            }
            guard let c = world.creatures.first(where: { $0.id == id }) else { continue }
            let before = bonds.bond(c.species.id).level
            if petted { bonds.addPet(c.species.id) } else { bonds.addPoke(c.species.id) }
            let after = bonds.bond(c.species.id)
            if after.level > before {
                world.setBond(after.strength, forSpecies: c.species.id)
                overlay.bondLevelUp(c)
                rebuildMenu()
            }
        }
    }

    /// Once a second: menu bar timer text, focus phases, reminders, time-together and late-night sleepiness.
    private func presenceInput() -> PresenceInput {
        PresenceInput(now: CACurrentMediaTime(), manuallyHidden: manuallyHidden, inCall: inCall,
                      hideDuringCalls: hideDuringCalls, idleSeconds: idleSeconds, lowPower: lowPower)
    }
    private var inCall = false, idleSeconds = 0.0, lowPower = false, lastCallCheck = 0.0
    private var lastTypingCheck = 0.0, typingSince: Double?, lastFriendSeedDay = ""
    let quests = QuestStore()

    /// Reads camera/mic/idle/power once a second and applies hide / show / away / welcome-back.
    private func updatePresence() {
        // Camera and microphone are checked every few seconds (walking the audio process list is not free).
        let t = CACurrentMediaTime()
        if !hideDuringCalls { inCall = false } else if t - lastCallCheck >= 3 {
            lastCallCheck = t
            inCall = SystemSignals.cameraInUse() || SystemSignals.microphoneInUse()
        }
        idleSeconds = SystemSignals.idleSeconds()
        world.userActive = idleSeconds < 90 && !presence.isHidden
        lowPower = SystemSignals.lowPowerMode
        for e in presence.update(presenceInput()) {
            switch e {
            case .hide:
                overlay.hidden = true
            case .show:
                overlay.hidden = false
                lastTick = CACurrentMediaTime()       // don't simulate the time they were away in one giant step
                refreshEnvironment()
                schedule(rate: 30)
            case .away:
                world.receive(.sleep)
            case .welcomeBack:
                world.receive(.wake)
                schedule(rate: 60)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { [weak self] in self?.world.receive(.wave) }
                // Postcards came while you were away: someone mentions it.
                if world.unreadMail > 0 {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.2) { [weak self] in
                        guard let self, let id = self.world.say() else { return }
                        let n = self.world.unreadMail
                        self.overlay.showBubble(n == 1 ? "A postcard came! 📬" : "\(n) postcards came! 📬", on: id, seconds: 3)
                    }
                }
            }
            rebuildMenu()
        }
    }

    @objc private func toggleHidden() {
        manuallyHidden.toggle()
        updatePresence()
    }

    @objc private func toggleHideDuringCalls() {
        hideDuringCalls.toggle()
        updatePresence()
        rebuildMenu()
    }

    private func saveBonsai() {
        if let d = world.bonsaiBook.encoded() { UserDefaults.standard.set(d, forKey: bonsaiKey) }
        bonsaiDirty = false
    }

    private func saveGrove() {
        if let d = world.grove.encoded() { UserDefaults.standard.set(d, forKey: groveKey) }
    }

    private func housekeeping(elapsed: Double) {
        updatePresence()
        if world.userActive { postMorningCard() }
        if terrariumBoard.prune(now: Date().timeIntervalSince1970) { bridge.sendStatus(terrariumBoard.snapshot(showNames: terrariumNames).json()) }
        // Where each one spends its time (for its favourite spot); out of full screen only, so it's their own choice.
        if !world.compact && !presence.isHidden {
            for c in world.creatures { if let p = world.placeName(of: c) { bonds.addSpot(c.species.id, p, seconds: min(elapsed, 2)) } }
            if Int(CACurrentMediaTime()) % 300 == 0 { bonds.save() }
        }
        // Claude Code used on this Mac in the last day? If not, the Gremlets keep their own busy day.
        world.claudeAround = Date().timeIntervalSince1970 - UserDefaults.standard.double(forKey: "claude.lastSeen") < 18 * 3600
        dock.tick(now: CACurrentMediaTime(), fullScreen: world.compact)
        friendVisits()
        // Lunchtime picnic (once a day, around noon) and a blanket late at night (once a night), while you're here.
        if world.userActive && !world.compact && !presence.isHidden && Int(CACurrentMediaTime()) % 15 == 0 {
            let hour = Calendar.current.component(.hour, from: Date()), day = BondStore.dayKey()
            if hour == 12, UserDefaults.standard.string(forKey: "garden.lastPicnic") != day, world.startPicnic() {
                UserDefaults.standard.set(day, forKey: "garden.lastPicnic")
            }
            if hour >= 0 && hour < 4, UserDefaults.standard.string(forKey: "garden.lastBlanket") != day,
               world.bringBlanket(towardX: Double(NSEvent.mouseLocation.x)) {
                UserDefaults.standard.set(day, forKey: "garden.lastBlanket")
            }
        }
        // Anniversaries: a flower crown all day, and a line in the scrapbook.
        if Int(CACurrentMediaTime()) % 20 == 0 {
            let crowned = Set(world.creatures.filter { bonds.isAnniversary($0.species.id) }.map(\.id))
            for c in world.creatures where crowned.contains(c.id) && !world.crowned.contains(c.id) {
                let line = "\(c.species.name): \(bonds.daysTogether(c.species.id)) days together"
                if !(dayLog[Date()].anniversaries ?? []).contains(line) {
                    dayLog.add { $0.anniversaries = ($0.anniversaries ?? []) + [line] }
                    overlay.showBubble("It's our \(bonds.daysTogether(c.species.id))th day together! 🌸", on: c.id, seconds: 6)
                }
            }
            world.crowned = crowned
        }
        world.eventsAllowed = epicEvents && !paused && !presence.isHidden && !focus.isFocusing
        if bonsaiDirty || Int(CACurrentMediaTime()) % 60 == 0 { saveBonsai() }
        world.checkLanternFestival(hour: Calendar.current.component(.hour, from: Date()))
        // Unless you've chosen a side, the nursery hangs on whichever screen edge has fewer desktop icons.
        if (UserDefaults.standard.object(forKey: "nursery.side") as? Double ?? 0) == 0, icons.enabled, let main = NSScreen.screens.first {
            let f = main.frame
            let left = icons.visible.filter { $0.rect.midX < f.minX + 190 }.count, right = icons.visible.filter { $0.rect.midX > f.maxX - 190 }.count
            let side: Double = left < right ? -1 : 1
            if side != world.nurserySide { world.nurserySide = side }
        }
        // Once: what's new in this version, from whoever's out.
        if !UserDefaults.standard.bool(forKey: "tour.grownWorld"), Int(CACurrentMediaTime() - launchTime) > 25, world.userActive, !presence.isHidden, let id = world.say() {
            UserDefaults.standard.set(true, forKey: "tour.grownWorld")
            overlay.showBubble("New: your Claude projects grow bonsai on their terminals now. Start a Claude Code session and watch, or try 'gremlet demo'. The Garden Journal is in the menu.", on: id, seconds: 16)
            world.receive(.wave)
        }
        // One postcard a day, for the time-lapse (a couple of minutes after launch, once things have settled).
        if !dailyPostcardTried && CACurrentMediaTime() - lastTick > -1 && Int(CACurrentMediaTime() - launchTime) > 120 && !presence.isHidden {
            dailyPostcardTried = true
            TimeLapse.saveToday(world: world, species: species)
        }
        if Int(CACurrentMediaTime()) % 60 == 0 {
            world.checkWishwillow(day: Int(Date().timeIntervalSinceReferenceDate / 86400))
            saveGrove()
        }
        // Clear nights bring the odd meteor shower (about one every couple of hours of evening work).
        if world.isNight && world.userActive && world.spectacle == nil && Double.random(in: 0..<1) < elapsed / (100 * 60) {
            world.requestEvent(.meteors)
        }
        focus.update()
        buddy.tick()
        dailyMoments()
        if icons.enabled && Int(Date().timeIntervalSince1970) % 15 == 0 { icons.refresh() }
        // Seasons and night-time for the garden; now and then a shooting star at night grants a wish.
        let cal = Calendar.current, nowDate = Date()
        // Previews (gremlet season winter / gremlet night on) hold for ten minutes.
        if let (m, until) = seasonOverride, Date() < until { world.month = m } else { seasonOverride = nil; world.month = cal.component(.month, from: nowDate) }
        if let (n, until) = nightOverride, Date() < until { world.isNight = n } else { nightOverride = nil; world.isNight = PropArt.isEvening }
        if world.isNight && world.userActive && !presence.isHidden && Double.random(in: 0..<1) < elapsed / (40 * 60) {
            wishOnAStar()
        }
        // The menu bar says what the Claude sessions need, when the focus timer isn't using it.
        let jobs = world.creatures.compactMap { $0.job }.filter { $0.kind == .claude && $0.phase != .leaving }
        let needs = jobs.filter(\.needsYou).count
        // Kept short: a crowded menu bar (a notch, a recording indicator) hides the widest item first. One session is
        // told by the tree icon alone; words only when Claude needs you or several sessions run.
        let claudeLabel: String? = jobs.count > 1 ? (needs > 0 ? "\(needs) need\(needs == 1 ? "s" : "") you" : "\(jobs.count) growing") : nil
        let title = focus.label ?? claudeLabel
        // The logo shows how Claude's doing at a glance.
        // (Swapped at most every couple of seconds: the status bar re-lays out on every image change, and a burst of
        // edits during a recording once made the item disappear until the next title change.)
        let tickNow = CACurrentMediaTime()
        if tickNow - lastIconSwap > 2.5 {
            // The logo: a third leaf on its sprout while Claude works, a lantern while Claude waits for you.
            let working = jobs.contains { $0.phase == .working && world.time - $0.lastToolTime < 90 }
            let wantIcon = MenuLogo.image(needs > 0 ? .waiting : working ? .working : .idle)
            if statusItem.button?.image !== wantIcon { statusItem.button?.image = wantIcon; lastIconSwap = tickNow }
        }
        if title != lastTitle {
            statusItem.button?.title = title.map { " " + $0 } ?? ""
            statusItem.button?.imagePosition = .imageLeading
            if (title == nil) != (lastTitle == nil) { rebuildMenu() }
            lastTitle = title
        }
        if !paused && !presence.isHidden && !presence.isAway {
            for id in Set(world.creatures.map(\.species.id)) { bonds.addTime(id, seconds: elapsed) }
        }
        if remindersOn && !focus.isFocusing && Date().timeIntervalSince(lastReminder) > 45 * 60 {
            world.receive(nextReminderIsWater ? .water : .stretch)
            nextReminderIsWater.toggle()
            lastReminder = Date()
            schedule(rate: 60)
        }
        let out = world.creatures.map(\.species.id)
        if access.tick(out: out, now: Date().timeIntervalSince1970) { endDemoSession() }
        if Int(CACurrentMediaTime()) % 600 == 0 { wallet?.refresh(access.ownership) }
        let hour = Calendar.current.component(.hour, from: Date())
        world.sleepyFactor = (hour >= 23 || hour < 5) ? 3 : 1     // gentle "time to log off" hint
        if Int(CACurrentMediaTime()) % 60 == 0 {
            for id in Set(world.creatures.map(\.species.id)) { bonds.markSeenToday(id) }
            bonds.save()
        }
    }

    @objc private func startFocus(_ sender: NSMenuItem) {
        focus.startFocus(minutes: Double(sender.representedObject as? Int ?? 25))
    }

    @objc private func stopFocus() {
        focus.stop()
        world.focusMode = false
        world.receive(.wake)
        rebuildMenu()
    }

    // MARK: AI companion

    private func dayStats() -> CompanionAI.Day {
        var d = CompanionAI.Day()
        d.focusMinutes = Int(focusLog.todayMinutes.rounded())
        d.streak = focusLog.streak
        d.plantsToday = overlay.seedBook.today
        d.seedsFound = overlay.seedBook.found
        d.seedsTotal = PlantKind.allCases.count
        d.claudeToday = buddy.log.todayCount
        d.gremletsOut = world.creatures.map { companion.nickname($0.species.id) ?? $0.species.name }
        return d
    }

    private func chatTarget(_ name: String?) -> Creature? {
        let want = (name ?? "").lowercased()
        return world.creatures.first { $0.species.id == want } ?? (want.isEmpty ? world.creatures.first : nil)
    }

    /// The chat page talks to a Gremlet; the reply also pops up in a speech bubble on the desktop, and any action
    /// it asks for (focus, garden, dance...) happens.
    private func sendChat(_ text: String, to c: Creature) {
        guard let sp = species[c.species.id] else { return }
        let bond = bonds.bond(c.species.id)
        world.receive(.wave)
        companion.reply(to: text, as: sp.info, bond: bond, day: dayStats()) { [weak self] reply, action in
            guard let self, let c = self.world.creatures.first(where: { $0.species.id == sp.info.id }) else { return }
            self.overlay.showBubble(String(reply.prefix(118)) + (reply.count > 118 ? "…" : ""), on: c.id, seconds: 7)
            if let action { self.perform(action, by: c) }
            self.bonds.addPet(c.species.id)        // talking counts as quality time
            self.schedule(rate: 60)
        }
    }

    private func perform(_ action: CompanionAI.Action, by c: Creature) {
        switch action {
        case .focus: focus.startFocus(minutes: 25); rebuildMenu()
        case .garden: _ = world.startHobby(c) || world.startHobbyNearCursor()
        case .dance: world.receive(.dance)
        case .wave: world.receive(.wave)
        case .hide: manuallyHidden = true; updatePresence(); rebuildMenu()
        case .nap: world.receive(.sleep)
        case .wish: wishOnAStar()
        case .water: for w in world.workers { _ = world.helpGarden(workerID: w.id) }
        }
    }

    private func openChat(with id: Int) {
        let name = world.creatures.first { $0.id == id }?.species.id ?? ""
        if let url = URL(string: "http://127.0.0.1:\(ControlServer.defaultPort)/chat#\(name)") { NSWorkspace.shared.open(url) }
    }

    @objc private func openChatMenu() { openChat(with: world.creatures.first?.id ?? 0) }

    /// Typing fast for a while: the Gremlets hush and tiptoe. A pause after a long stretch: they stretch and play.
    /// (Only when the last key was pressed, from the system's idle counter: no key logging, no permission.)
    private func updateTyping() {
        let now = CACurrentMediaTime()
        guard now - lastTypingCheck >= 0.25 else { return }
        lastTypingCheck = now
        let sinceKey = CGEventSource.secondsSinceLastEventType(.combinedSessionState, eventType: .keyDown)
        if sinceKey < 1.2 {
            if typingSince == nil { typingSince = now }
        } else if sinceKey > 4, let start = typingSince {
            let streak = now - sinceKey - start
            typingSince = nil
            if world.hushed {
                world.hushed = false
                if streak > 30 && !world.compact { world.stretchBreak() }
            }
        }
        if let start = typingSince, now - start > 12, !world.hushed { world.hushed = true }
    }

    /// Double-click a Gremlet: it turns and waves, and a little card says who it is, how long you've been together and
    /// where it likes to be.
    /// Right-click a Gremlet: what it could do for you right now.
    private func showAskMenu(_ id: Int) {
        guard let c = world.creatures.first(where: { $0.id == id }) else { return }
        let menu = NSMenu()
        menu.autoenablesItems = false
        let mood = c.isAsleep || c.homeUntil != nil ? "fast asleep" : c.energy > 0.65 ? "full of beans" : c.energy > 0.3 ? "content" : "a bit sleepy"
        let head = NSMenuItem(title: "\(c.species.name) · \(mood)", action: nil, keyEquivalent: "")
        head.isEnabled = false
        menu.addItem(head)
        if let j = c.job, j.kind == .claude {
            let busy = NSMenuItem(title: "Busy on your session\(j.label.map { ": \($0)" } ?? "")", action: nil, keyEquivalent: "")
            busy.isEnabled = false
            menu.addItem(busy)
        }
        let ideas = world.ideas(for: c)
        if !ideas.isEmpty {
            menu.addItem(.separator())
            for idea in ideas {
                let item = NSMenuItem(title: idea.title, action: #selector(askPicked(_:)), keyEquivalent: "")
                item.target = self
                item.representedObject = [id, idea.rawValue] as [Any]
                menu.addItem(item)
            }
        }
        menu.addItem(.separator())
        let hello = NSMenuItem(title: "Say hello", action: #selector(askPicked(_:)), keyEquivalent: "")
        hello.target = self
        hello.representedObject = [id, "hello"] as [Any]
        menu.addItem(hello)
        menu.popUp(positioning: nil, at: NSEvent.mouseLocation, in: nil)
    }

    @objc private func askPicked(_ sender: NSMenuItem) {
        guard let pair = sender.representedObject as? [Any], let id = pair.first as? Int, let raw = pair.last as? String,
              let c = world.creatures.first(where: { $0.id == id }) else { return }
        if raw == "hello" { sayHello(id); return }
        guard let idea = Idea(rawValue: raw) else { return }
        if world.ask(c, idea) {
            overlay.ecoFX.handle(world.drainEcoEvents())
            if [.snack].contains(idea) == false, Int.random(in: 0..<2) == 0 {
                overlay.showBubble(["On it!", "Okay!", "Ooh, yes!", "Can do!"].randomElement()!, on: id, seconds: 1.4)
            }
        } else {
            overlay.showBubble(["Hmm, not right now.", "Can't from here!", "Maybe later?"].randomElement()!, on: id, seconds: 1.6)
        }
        schedule(rate: 60)
    }

    private func sayHello(_ id: Int) {
        guard let c = world.creatures.first(where: { $0.id == id }) else { return }
        world.sayHello(c)
        let key = c.species.id
        let days = bonds.daysTogether(key)
        let together = days <= 1 ? "We met today!" : "We've been together \(days) days."
        let spot = bonds.favouriteSpot(key).map { " Favourite spot: \($0)." } ?? ""
        overlay.showBubble("Hi, I'm \(c.species.name)! \(together)\(spot)", on: id, seconds: 6)
        schedule(rate: 60)
    }

    /// Good morning the first time you're around each day; a recap of the day in the evening.
    private func dailyMoments() {
        guard world.userActive, !presence.isHidden, let c = world.creatures.filter({ $0.isGrounded && $0.job == nil }).randomElement(),
              let sp = species[c.species.id] else { return }
        let today = BondStore.dayKey()
        let hour = Calendar.current.component(.hour, from: Date())
        var kind: String?
        if lastMorning != today && hour >= 5 && hour < 12 { kind = "morning"; lastMorning = today; UserDefaults.standard.set(today, forKey: "companion.lastMorning") }
        else if lastEvening != today && hour >= 18 { kind = "evening"; lastEvening = today; UserDefaults.standard.set(today, forKey: "companion.lastEvening") }
        guard let kind else { return }
        let id = c.id
        companion.moment(kind, as: sp.info, bond: bonds.bond(sp.info.id), day: dayStats()) { [weak self] line in
            self?.world.receive(.wave)
            self?.overlay.showBubble(line, on: id, seconds: 8)
            // In the morning, what yesterday added up to (the garden journal has the rest).
            // In the evening, today's flower goes into the scrapbook.
            if kind == "evening", let self, let k = Scrapbook.pressed(self.dayLog[Date()]) {
                DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
                    self.overlay.showBubble("Pressed a \(k == .berries ? "berry sprig" : k == .dandelion ? "dandelion" : k.rawValue) into today's scrapbook page.", on: id, seconds: 7)
                }
            }
            if kind == "morning", let y = self?.dayLog.yesterdayLine {
                DispatchQueue.main.asyncAfter(deadline: .now() + 9) { self?.overlay.showBubble(y + " The journal's in the menu.", on: id, seconds: 10) }
            }
        }
    }

    /// gremlets://say?text=…, gremlets://focus?minutes=50, gremlets://hobby, gremlets://chat?name=kindlet,
    /// gremlets://send?name=kindlet, gremlets://wish, gremlets://dance … (for Shortcuts, Raycast, Alfred, scripts).
    func application(_ application: NSApplication, open urls: [URL]) {
        for url in urls where url.scheme == "gremlets" {
            let action = (url.host ?? "") + url.path
            var q: [String: String] = [:]
            for item in URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems ?? [] { q[item.name] = item.value.map { $0.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? $0 } }
            switch action {
            case "chat": openChat(with: chatTarget(q["name"])?.id ?? 0)
            case "pair": pairPhone()
            case "journal": openJournal()
            case "scrapbook": openScrapbook()
            case "wrapped": saveWrapped()
            case "demo": playDemo()
            case "forest": saveForest()
            case "recap": saveRecap()
            case "card":
                let name = Self.decoded(q["project"] ?? "")
                if let t = name.isEmpty ? world.bonsaiBook.trees.max(by: { $0.lastSeen < $1.lastSeen }) : world.bonsaiBook[name],
                   let url = TreeCard.make(t, world: world) { NSWorkspace.shared.activateFileViewerSelecting([url]) }
            case "send": _ = handleControl(method: "POST", path: "/phone/send", query: q)
            default: _ = handleControl(method: "POST", path: "/" + action, query: q)
            }
        }
    }

    /// A shooting star: the next seed planted will be something special.
    private func wishOnAStar() {
        overlay.shootingStar()
        world.makeWish()
        if let c = world.creatures.filter({ $0.isGrounded }).randomElement() {
            overlay.showBubble("A shooting star! Make a wish ✨", on: c.id, seconds: 4)
        }
        schedule(rate: 60)
        rebuildMenu()
    }

    @objc private func pairPhone() {
        phone.pair()
        if let url = URL(string: "http://127.0.0.1:\(ControlServer.defaultPort)/pair") { NSWorkspace.shared.open(url) }
        rebuildMenu()
    }

    // MARK: Claude talking to the Gremlets (scripts/gremlets-mcp.py)

    private func handleMCP(_ q: [String: String]) -> (Int, String) {
        func esc(_ s: String) -> String { String(String(data: (try? JSONSerialization.data(withJSONObject: [s])) ?? Data(), encoding: .utf8)?.dropFirst().dropLast() ?? "\"\"") }
        let project = Self.decoded(q["project"] ?? "")
        let worker = world.creatures.first { $0.job?.kind == .claude && $0.job?.label == project }
            ?? world.creatures.first { $0.job?.kind == .claude } ?? world.creatures.first
        let text = String(Self.decoded(q["text"] ?? q["message"] ?? q["reason"] ?? q["current"] ?? "").prefix(80))
        schedule(rate: 60)
        switch q["action"] ?? "" {
        case "say":
            guard let w = worker, !text.isEmpty else { return (400, #"{"ok":false,"error":"nothing to say, or no Gremlets out"}"#) }
            overlay.showBubble(text, on: w.id, seconds: 6)
            return (200, #"{"ok":true,"gremlet":"\#(w.species.name)"}"#)
        case "celebrate":
            world.celebrate(around: worker?.id)
            if let w = worker {
                overlay.sparkle(at: w.pos + Vec2(0, w.size.y))
                overlay.showBubble(text.isEmpty ? "🎉" : "🎉 " + text, on: w.id, seconds: 4)
            }
            return (200, #"{"ok":true}"#)
        case "plan":
            guard let w = worker, w.job?.kind == .claude, let total = q["total"].flatMap(Int.init), let done = q["done"].flatMap(Int.init) else {
                return (409, #"{"ok":false,"error":"no Claude session Gremlet for this project right now (the plan shows on its terminal)"}"#)
            }
            world.claudePlan(workerID: w.id, total: total, done: done)
            if !text.isEmpty { overlay.showBubble("Next: " + text, on: w.id, seconds: 4) }
            return (200, #"{"ok":true}"#)
        case "request_review":
            guard let w = worker else { return (409, #"{"ok":false,"error":"no Gremlets out"}"#) }
            world.requestReview(workerID: w.id)
            overlay.showBubble(text.isEmpty ? "Come take a look?" : text, on: w.id, seconds: 10)
            return (200, #"{"ok":true}"#)
        case "status":
            let list = world.creatures.map { c -> String in
                let doing: String = c.job?.kind == .claude ? "helping Claude on \(c.job?.label ?? "a project")"
                    : c.expedition != nil ? "on an expedition" : c.isClimbing ? "climbing a vine" : c.isAsleep ? "asleep" : "\(c.activity)"
                return #"{"name":\#(esc(c.species.name)),"doing":\#(esc(doing))}"#
            }.joined(separator: ",")
            return (200, #"{"ok":true,"gremlets":[\#(list)],"moss_minutes":\#(Int(world.mossMinutes))}"#)
        default:
            return (400, #"{"ok":false,"error":"unknown action"}"#)
        }
    }

    /// The front-most normal window of the front-most app (the one "stand on text" scans).
    private func frontWindowForSense() -> (id: Int, frame: CGRect)? {
        guard sense.standOnText, let pid = NSWorkspace.shared.frontmostApplication?.processIdentifier, pid != ProcessInfo.processInfo.processIdentifier,
              let list = CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID) as? [[String: Any]] else { return nil }
        for w in list where (w[kCGWindowLayer as String] as? Int) == 0 && (w[kCGWindowOwnerPID as String] as? Int32) == pid {
            guard let id = w[kCGWindowNumber as String] as? Int, let b = w[kCGWindowBounds as String] as? [String: Double],
                  let width = b["Width"], let height = b["Height"], width > 200, height > 150 else { continue }
            return (id, CGRect(x: b["X"] ?? 0, y: b["Y"] ?? 0, width: width, height: height))
        }
        return nil
    }

    /// Full screen: the house hangs in the top-right corner, below the notch band.
    static func cornerHome() -> NotchHome? {
        guard let s = NSScreen.screens.first else { return nil }
        let top: Double
        if #available(macOS 12, *) { top = Double(s.safeAreaInsets.top) } else { top = 0 }
        return NotchHome(minX: s.frame.maxX - 206, maxX: s.frame.maxX - 12, menuBottom: s.frame.maxY - top)
    }

    /// The built-in screen's notch (MacBooks from 2021 on): its left and right edges and the bottom of the menu bar.
    static func notchHome() -> NotchHome? {
        guard let s = NSScreen.screens.first else { return nil }
        if #available(macOS 12, *), s.safeAreaInsets.top > 0, let l = s.auxiliaryTopLeftArea, let r = s.auxiliaryTopRightArea {
            let lo = s.frame.minX + l.maxX, hi = s.frame.minX + r.minX
            if hi - lo > 60, hi - lo < 400 { return NotchHome(minX: lo, maxX: hi, menuBottom: s.visibleFrame.maxY) }
        }
        // No notch: the house hangs from the middle of the menu bar instead.
        return NotchHome(minX: s.frame.midX - 95, maxX: s.frame.midX + 95, menuBottom: s.visibleFrame.maxY)
    }

    @objc private func askWeatherCity() {
        let alert = NSAlert()
        alert.messageText = "Weather where you are"
        alert.informativeText = "Type your city. The Gremlets get the weather there from Open-Meteo every 20 minutes (no account, no location permission)."
        let field = NSTextField(frame: NSRect(x: 0, y: 0, width: 240, height: 24))
        field.placeholderString = "e.g. Portland"
        field.stringValue = weatherService.place?.name ?? ""
        alert.accessoryView = field
        alert.addButton(withTitle: "Use This City"); alert.addButton(withTitle: "Cancel")
        NSApp.activate(ignoringOtherApps: true)
        alert.window.initialFirstResponder = field
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        weatherService.setCity(field.stringValue) { [weak self] found in
            if found == nil {
                let a = NSAlert(); a.messageText = "Couldn't find that city"; a.informativeText = "Try just the city's name, like \"Austin\"."; a.runModal()
            }
            self?.rebuildMenu()
        }
    }

    @objc private func weatherOff() { weatherService.place = nil; rebuildMenu() }

    @objc private func toggleSense(_ sender: NSMenuItem) {
        switch sender.representedObject as? String {
        case "text":
            sense.standOnText.toggle()
            if sense.standOnText && !ScreenSense.hasScreenAccess { ScreenSense.requestScreenAccess() }
        case "clips":
            sense.highlightClips.toggle()
            if sense.highlightClips && !ScreenSense.hasScreenAccess { ScreenSense.requestScreenAccess() }
        default: break
        }
        refreshEnvironment()
        rebuildMenu()
    }

    /// Clicking a Claude session's Gremlet brings its window to the front (Terminal: that exact window).
    private func focusSession(of c: Creature) {
        guard let wid = c.job?.windowID,
              let info = (CGWindowListCopyWindowInfo([.optionIncludingWindow], CGWindowID(wid)) as? [[String: Any]])?.first,
              let pid = info[kCGWindowOwnerPID as String] as? Int32, let app = NSRunningApplication(processIdentifier: pid) else { return }
        overlay.showBubble("This way! →", on: c.id, seconds: 1.5)
        if app.localizedName == "Terminal" {
            let p = Process()
            p.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
            p.arguments = ["-e", "tell application \"Terminal\"", "-e", "set index of window id \(wid) to 1", "-e", "activate", "-e", "end tell"]
            p.standardError = FileHandle.nullDevice
            try? p.run()
        } else {
            app.activate()
        }
    }

    // MARK: Overgrowth

    private let mossKey = "moss.v1"
    private var lastMossSave: CFTimeInterval = 0
    func saveMoss() {
        UserDefaults.standard.set(world.mossMinutes, forKey: mossKey)
        UserDefaults.standard.set(world.mossCare, forKey: "moss.care")
        UserDefaults.standard.set(world.houseDaisies, forKey: "house.daisies")
        UserDefaults.standard.set(world.pantry, forKey: "house.pantry")
        UserDefaults.standard.set(world.homeCare, forKey: "house.care")
        UserDefaults.standard.set(world.rainBarrel, forKey: "house.barrel")
        UserDefaults.standard.set(world.patchSaved, forKey: "house.patch")
        UserDefaults.standard.set(world.seedTinSaved, forKey: "house.seeds")
        UserDefaults.standard.set(world.porchLeaves, forKey: "house.leaves")
        UserDefaults.standard.set(world.roofSnow, forKey: "house.snow")
        UserDefaults.standard.set(world.fireflyJar, forKey: "house.jar")
        if let d = try? JSONEncoder().encode(world.mailbox) { UserDefaults.standard.set(d, forKey: "house.mail") }
        if let d = try? JSONEncoder().encode(world.winFlags) { UserDefaults.standard.set(d, forKey: "winFlags.v1") }
        UserDefaults.standard.set(world.houseDaisiesDay, forKey: "house.daisiesDay")
    }

    // MARK: Watching the Mac

    /// Cheap checks each tick: the screenshot tool appearing (pose!), and every half minute the battery.
    private func watchTheMac() {
        let shot = WindowTracker.screenshotToolVisible
        if shot && !screenshotWasVisible { world.machineSignal(.screenshot); schedule(rate: 60) }
        screenshotWasVisible = shot
        let now = CACurrentMediaTime()
        guard now - lastBatteryCheck > 30 else { return }
        lastBatteryCheck = now
        guard let b = SystemSignals.battery() else { return }
        if !b.charging && b.percent <= 15 && !batteryLowShown {
            batteryLowShown = true
            world.machineSignal(.batteryLow(percent: b.percent))
        } else if b.charging && batteryLowShown {
            batteryLowShown = false
            world.machineSignal(.pluggedIn)
        } else if b.percent > 20 {
            batteryLowShown = false
        }
    }

    // MARK: Screen link (the doorway)

    @objc private func linkScreen(_ sender: NSMenuItem) {
        bridge.create(side: sender.representedObject as? String ?? "right")
        updateDoor()
        showLinkCode()
    }

    /// Visiting a friend's Mac: a room on the relay both Macs join; the doorway is this Mac's right edge.
    /// Opens the postcard a traveller brought home: a little pixel card of where it went, and takes in the mail.
    @objc private func openPostcard() {
        guard let card = world.postcard else { return }
        let W = 420.0, H = 260.0
        let img = NSImage(size: NSSize(width: W, height: H))
        img.lockFocus()
        let ctx = NSGraphicsContext.current!.cgContext
        ctx.interpolationQuality = .none
        // A sky, a meadow, the traveller, and the hanging house in the corner.
        NSGradient(colors: [NSColor(red: 0.55, green: 0.78, blue: 0.98, alpha: 1), NSColor(red: 0.97, green: 0.92, blue: 0.82, alpha: 1)])?.draw(in: NSRect(x: 0, y: 0, width: W, height: H), angle: -90)
        NSColor(red: 0.42, green: 0.70, blue: 0.32, alpha: 1).setFill(); NSRect(x: 0, y: 0, width: W, height: 54).fill()
        let house = NotchArt.house(lit: true, month: world.month, stage: world.houseStage)
        ctx.draw(house, in: CGRect(x: W - 130, y: H - 30 - Double(house.height) * 4, width: Double(house.width) * 4, height: Double(house.height) * 4))
        if let sp = species[card.species], let frame = sp.frames.first {
            let s = 4.0
            ctx.draw(frame, in: CGRect(x: 60, y: 50, width: Double(frame.width) * s, height: Double(frame.height) * s))
        }
        let name = species[card.species]?.info.name ?? "A Gremlet"
        NSAttributedString(string: "Greetings from \(card.from)!", attributes: [.font: NSFont.systemFont(ofSize: 22, weight: .heavy), .foregroundColor: NSColor(red: 0.15, green: 0.17, blue: 0.27, alpha: 1)]).draw(at: NSPoint(x: 24, y: H - 46))
        NSAttributedString(string: "Love, \(name)", attributes: [.font: NSFont.systemFont(ofSize: 15, weight: .semibold), .foregroundColor: NSColor(red: 0.15, green: 0.17, blue: 0.27, alpha: 0.8)]).draw(at: NSPoint(x: 26, y: H - 72))
        NSColor(white: 1, alpha: 0.9).setStroke(); let b = NSBezierPath(rect: NSRect(x: 6, y: 6, width: W - 12, height: H - 12)); b.lineWidth = 4; b.stroke()
        img.unlockFocus()
        let a = NSAlert()
        a.messageText = "A postcard from \(card.from)"
        a.informativeText = "\(name) brought it home and left it in the mailbox."
        let view = NSImageView(frame: NSRect(x: 0, y: 0, width: W, height: H)); view.image = img
        a.accessoryView = view
        NSApp.activate(ignoringOtherApps: true)
        a.runModal()
        world.postcard = nil
        world.mailWaiting = false
        rebuildMenu()
    }

    @objc private func inviteFriend() {
        if !bridge.linked { bridge.create(side: "right"); updateDoor() }
        let code = bridge.friendCode ?? ""
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(code, forType: .string)
        let a = NSAlert()
        a.messageText = "Your friend code: \(code)"
        a.informativeText = "It's copied. Send it to a friend who has Gremlets; they choose Join a Friend's Mac and paste it. Your Gremlets walk off the right edge of your screen and onto theirs (and theirs onto yours), and wander home when they're ready. Only Gremlet names travel, through a public relay."
        NSApp.activate(ignoringOtherApps: true)
        a.runModal()
        rebuildMenu()
    }

    @objc private func joinFriend() {
        let a = NSAlert()
        a.messageText = "Join a friend's Mac"
        a.informativeText = "Paste the code your friend sent you."
        let field = NSTextField(frame: NSRect(x: 0, y: 0, width: 240, height: 24))
        a.accessoryView = field
        a.addButton(withTitle: "Join"); a.addButton(withTitle: "Cancel")
        NSApp.activate(ignoringOtherApps: true)
        a.window.initialFirstResponder = field
        guard a.runModal() == .alertFirstButtonReturn else { return }
        if !bridge.join(code: field.stringValue) {
            let e = NSAlert(); e.messageText = "That code doesn't look right"; e.informativeText = "Paste the whole code your friend sent (letters, numbers and a dash)."; e.runModal()
        }
        updateDoor()
        rebuildMenu()
    }

    @objc private func showLinkCode() {
        if let url = URL(string: "http://127.0.0.1:\(ControlServer.defaultPort)/link") { NSWorkspace.shared.open(url) }
        rebuildMenu()
    }

    @objc private func unlinkScreen() {
        bridge.unlink()
        updateDoor()
        rebuildMenu()
    }

    @objc private func crossNow() {
        updateDoor()
        guard world.door != nil else {
            let a = NSAlert()
            a.messageText = "The other screen isn't open yet"
            a.informativeText = "Your friend needs Gremlets running with the same code joined. Once their Mac says hello, the hollow log at the edge of your screen lights up."
            NSApp.activate(ignoringOtherApps: true); a.runModal(); return
        }
        if world.sendThroughDoor() { overlay.ecoFX.handle(world.drainEcoEvents()); schedule(rate: 60) }
        else if let c = world.creatures.first { overlay.showBubble("Busy right now! In a sec…", on: c.id, seconds: 2) }
    }

    /// While a friend's Mac (or the iPad) is linked: the first hello is a little moment (the log lights up and
    /// someone goes over to say hi), then every few minutes one goes visiting, and visitors wander home after a while.
    private func friendVisits() {
        let now = CACurrentMediaTime()
        overlay.peerOnline = bridge.linked && bridge.peerOnline
        guard bridge.linked, bridge.peerOnline, world.door != nil, !presence.isHidden else { peerWasOnline = bridge.peerOnline; return }
        if !peerWasOnline {
            peerWasOnline = true
            let who = bridge.peerIsMac ? "your friend's Mac" : "the iPad"
            if let c = world.creatures.first(where: { guests[$0.id] == nil }) {
                overlay.showBubble("The log goes through to \(who)! 🪵", on: c.id, seconds: 3.5)
            }
            nextVisitAt = now + 8
            schedule(rate: 60)
        }
        // Visitors head home after 2-4 minutes (one at a time).
        if let (id, _) = guestSince.first(where: { now - $0.value > 120 + Double($0.key % 7) * 20 }) {
            if world.creatures.contains(where: { $0.id == id }) {
                if world.sendThroughDoor(preferring: id) {
                    overlay.showBubble(["Home time! Thanks! 👋", "Back to my Mac!", "Bye bye!"].randomElement()!, on: id, seconds: 2)
                    overlay.ecoFX.handle(world.drainEcoEvents())
                    schedule(rate: 60)
                }
            } else { guestSince[id] = nil }
        }
        // One of ours goes visiting every few minutes, keeping at least one at home.
        let ownHere = world.creatures.filter { guests[$0.id] == nil }.count
        if now >= nextVisitAt, ownHere >= 2 || (ownHere == 1 && bridge.away.isEmpty && guests.isEmpty == false) {
            nextVisitAt = now + Double.random(in: 180...360)
            let pick = world.creatures.filter { guests[$0.id] == nil && $0.job == nil }.randomElement()
            if world.sendThroughDoor(preferring: pick?.id) {
                overlay.ecoFX.handle(world.drainEcoEvents())
                schedule(rate: 60)
            }
        }
    }

    /// The doorway is open while the other screen is around.
    private func updateDoor() {
        let want: Double? = bridge.linked && bridge.peerOnline ? (bridge.side == "left" ? -1 : 1) : nil
        guard want != world.door else { return }
        world.door = want
        refreshEnvironment()
        schedule(rate: 60)
    }

    /// A Gremlet walked out through the doorway: it carries on, on the other screen.
    private func crossOut(_ c: Creature) {
        guard let main = WindowTracker.screens().first else { return }
        let usable = max(1, main.h - 80)
        let y = ((c.pos.y - main.minY) / usable).clamped(0, 1)
        let air = !c.isGrounded
        // Ours carry our id; a visitor carries its own home's, so it's recognised there as coming home.
        let owner = guests.removeValue(forKey: c.id) ?? bridge.owner
        guestSince[c.id] = nil
        bridge.cross(["type": "walk", "species": c.species.id, "y": y, "vx": Int(c.vel.x), "vy": Int(c.vel.y), "air": air, "owner": owner])
        let wasGuest = owner != bridge.owner
        let edgeX = (world.door ?? 1) > 0 ? main.maxX - 14 : main.minX + 14
        overlay.sparkle(at: Vec2(edgeX, c.pos.y + c.size.y * 0.5))
        world.endJob(c.id)
        world.remove(c.id)
        if !wasGuest { bridge.away = bridge.away + [c.species.id] }
        saveRoster()
        overlay.render()
        rebuildMenu()
    }

    /// The sky ferry sailed out through the doorway: it carries on, with its passengers, on the other screen.
    private func ferryCrossedOut(riders: [String], yFrac: Double) {
        bridge.cross(["type": "visitor", "kind": "ferry", "y": yFrac, "riders": riders])
        if let main = WindowTracker.screens().first {
            let edgeX = (world.door ?? 1) > 0 ? main.maxX - 14 : main.minX + 14
            overlay.sparkle(at: Vec2(edgeX, main.minY + yFrac * max(1, main.h - 80)))
        }
        guard !riders.isEmpty else { return }
        bridge.away = bridge.away + riders
        saveRoster()
        rebuildMenu()
    }

    /// The ferry comes in from the other screen, with passengers from there aboard.
    private func ferryArrivesThroughBridge(riders: [String], yFrac: Double) {
        let infos = riders.prefix(3).compactMap { species[$0]?.info }
        bridge.away = bridge.away.filter { !riders.contains($0) }
        if world.door == nil { updateDoor() }
        let arrived = world.ferryArrivesThroughDoor(riders: infos, yFrac: yFrac)
        if arrived.count < infos.count {
            // The ferry's already out here: the passengers walk in through the doorway instead.
            for sp in infos.dropFirst(arrived.count) { world.arriveThroughDoor(sp, yFrac: 0, vx: 70, vy: 0, airborne: false) }
        }
        saveRoster()
        schedule(rate: 60)
        if let c = arrived.first {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
                guard let self, self.world.creatures.contains(where: { $0.id == c.id }) else { return }
                self.overlay.showBubble(["All ashore? Not yet!", "Hello, Mac! ⛵️", "What a view!"].randomElement()!, on: c.id, seconds: 2.4)
            }
        }
        rebuildMenu()
    }

    /// A Gremlet comes in from the other screen, through the doorway, keeping its stride.
    private func arriveThroughBridge(_ w: ScreenBridge.Walk) {
        guard let sp = species[w.species], let main = WindowTracker.screens().first else { return }
        // Ours coming home (by our id, or for the web habitat which doesn't tag, by the away list), or a visitor.
        let cameHome = w.owner.map { $0 == bridge.owner } ?? bridge.away.contains(w.species)
        if cameHome { bridge.away = bridge.away.filter { $0 != w.species } }
        if world.door == nil { updateDoor() }
        guard let c = world.arriveThroughDoor(sp.info, yFrac: w.y, vx: w.vx, vy: w.vy, airborne: w.air) else { return }
        overlay.ecoFX.handle([.tunnelPop(Vec2(c.pos.x.clamped(main.minX + 24, main.maxX - 24), c.pos.y), by: c.id)])
        // Home from a trip with a postcard for the mailbox.
        // Seeds for the vegetable patch: brought back from a friend's Mac, or brought along by a friend's Gremlet.
        if cameHome, bridge.peerIsMac, let crop = world.newFriendCrop {
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) { [weak self] in self?.world.receiveSeeds(crop, by: c.id) }
        } else if let o = w.owner, o != bridge.owner {
            DispatchQueue.main.asyncAfter(deadline: .now() + 6) { [weak self] in self?.world.receiveSeeds(World.friendCrop(for: o), by: c.id) }
        }
        if cameHome {
            world.mailWaiting = true
            world.postcard = (bridge.peerIsMac ? "a friend's Mac" : "your iPad", w.species)
        }
        // (or a visitor arriving from a friend's Mac: a guest, sent home with its own tag when it leaves).
        if let o = w.owner, o != bridge.owner {
            guests[c.id] = o
            guestSince[c.id] = CACurrentMediaTime()
            // A friend's Gremlet brings a seed from home: a flower in their own colour (once per visit day).
            let tint = o.utf8.reduce(UInt32(2_166_136_261)) { ($0 ^ UInt32($1)) &* 16_777_619 } & 0xFFFFFF | 0x404040
            if lastFriendSeedDay != BondStore.dayKey() + o {
                lastFriendSeedDay = BondStore.dayKey() + o
                DispatchQueue.main.asyncAfter(deadline: .now() + 4) { [weak self] in _ = self?.world.friendSeed(tint: tint, by: c.id) }
            }
        }
        if bridge.peerIsMac {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
                guard let self, self.world.creatures.contains(where: { $0.id == c.id }) else { return }
                self.overlay.showBubble(cameHome ? "Back! I brought a postcard 💌" : "Hi! Just visiting 🎒", on: c.id, seconds: 2.6)
            }
            saveRoster(); schedule(rate: 60); rebuildMenu()
            return
        }
        let edgeX = (world.door ?? 1) > 0 ? main.maxX - 14 : main.minX + 14
        overlay.sparkle(at: Vec2(edgeX, c.pos.y + c.size.y * 0.5))
        saveRoster()
        schedule(rate: 60)
        let lines = ["Made it! ✨", "Hello, Mac!", "I walked here!", "Whoa, big screen."]
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) { [weak self] in
            guard let self, self.world.creatures.contains(where: { $0.id == c.id }) else { return }
            self.overlay.showBubble(lines.randomElement()!, on: c.id, seconds: 2.4)
        }
        rebuildMenu()
    }

    @objc private func unlinkPhone() {
        phone.unpair()
        rebuildMenu()
    }

    /// Into the portal it goes; it pops out on the phone.
    @objc private func sendToPhone(_ sender: NSMenuItem) {
        guard let id = sender.representedObject as? Int, let c = world.creatures.first(where: { $0.id == id }) else { return }
        let speciesID = c.species.id
        world.endJob(id)
        overlay.showBubble("Off to your phone! 📱", on: id, seconds: 1.5)
        overlay.portal(at: Vec2(c.pos.x, c.pos.y + c.size.y * 0.45))
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.7) { [weak self] in
            guard let self else { return }
            self.world.remove(id)
            self.overlay.render()
            self.phone.sendToPhone(species: speciesID)
            self.saveRoster()
            self.rebuildMenu()
        }
    }

    /// Back from the phone: out of a portal near the bottom of the screen, with whatever it grew there.
    private func arriveFromPhone(_ a: PhoneLink.Arrival) {
        guard let sp = species[a.species] else { return }
        phone.onPhone = phone.onPhone.filter { $0 != a.species }
        let screens = WindowTracker.screens()
        guard let main = screens.first else { return }
        let x = main.maxX - 160
        let at = Vec2(x, main.minY + 60)
        overlay.portal(at: at)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
            guard let self else { return }
            let c = self.world.spawn(sp.info, at: Vec2(x, main.minY + 20))
            self.saveRoster()
            self.overlay.render()
            let grew = a.harvest.map { ($0.golden ? "golden " : "") + $0.kind.name.lowercased() }
            let text = grew.isEmpty ? "I'm back! 📱→💻" : "I'm back! Grew: " + grew.prefix(4).joined(separator: ", ") + (grew.count > 4 ? "…" : "")
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { self.overlay.showBubble(text, on: c.id, seconds: 6) }
            self.overlay.receiveHarvest(a.harvest, nearX: x)
            self.schedule(rate: 60)
            self.rebuildMenu()
        }
    }

    private func chatState(_ name: String?) -> String {
        func esc(_ s: String) -> String {
            let d = try? JSONSerialization.data(withJSONObject: [s])
            return String(String(data: d ?? Data(), encoding: .utf8)?.dropFirst().dropLast() ?? "\"\"")
        }
        let target = chatTarget(name)
        let gremlets = world.creatures.map { c -> String in
            let b = bonds.bond(c.species.id)
            let busy = c.job != nil ? "gardening" : c.isAsleep ? "napping" : "around"
            return #"{"id":\#(esc(c.species.id)),"name":\#(esc(c.species.name)),"nick":\#(esc(companion.nickname(c.species.id) ?? "")),"bond":\#(esc(b.name)),"element":\#(esc(c.species.element)),"family":\#(esc(c.species.family)),"doing":\#(esc(busy))}"#
        }.joined(separator: ",")
        let history = target.map { companion.history($0.species.id).suffix(40).map { #"{"role":\#(esc($0.role)),"text":\#(esc($0.text))}"# }.joined(separator: ",") } ?? ""
        let day = dayStats()
        return #"{"ai":\#(companion.hasKey),"problem":\#(esc(companion.lastProblem ?? "")),"me":\#(esc(companion.userName ?? "")),"target":\#(esc(target?.species.id ?? "")),"gremlets":[\#(gremlets)],"history":[\#(history)],"day":{"focus":\#(day.focusMinutes),"streak":\#(day.streak),"plants":\#(day.plantsToday),"seeds":\#(day.seedsFound),"seedsTotal":\#(day.seedsTotal),"claude":\#(day.claudeToday)}}"#
    }

    /// The chat page (127.0.0.1 only). Portraits are the Gremlets' own first sprite frames.
    private func chatPage() -> String {
        var portraits: [String] = []
        for c in world.creatures {
            guard let sp = species[c.species.id], let f = sp.frames.first,
                  let png = NSBitmapImageRep(cgImage: f).representation(using: .png, properties: [:]) else { continue }
            portraits.append("\"\(c.species.id)\":\"data:image/png;base64,\(png.base64EncodedString())\"")
        }
        return ChatPage.html(portraitsJSON: "{" + portraits.joined(separator: ",") + "}")
    }

    /// The Grove: each plant's level and what it does, how many Claude tasks until the next plot, and the events.
    private func groveMenuItem() -> NSMenuItem {
        let g = world.grove
        let item = NSMenuItem(title: "Grove · \(g.tasks) Claude task\(g.tasks == 1 ? "" : "s")", action: nil, keyEquivalent: "")
        let sub = NSMenu()
        func info(_ t: String, tip: String? = nil) { let i = NSMenuItem(title: t, action: nil, keyEquivalent: ""); i.isEnabled = false; i.toolTip = tip; sub.addItem(i) }
        info("Every Claude task you finish grows every plant here.")
        let houses = g.village.filter { !$0.biome.hasPrefix("item:") && $0.biome != "mine" }.count
        info("Today: \(world.tasksToday) Claude task\(world.tasksToday == 1 ? "" : "s") · village: \(houses) building\(houses == 1 ? "" : "s")")
        sub.addItem(.separator())
        for p in g.plants {
            let bar = String(repeating: "■", count: Int((p.levelProgress * 6).rounded())) + String(repeating: "□", count: 6 - Int((p.levelProgress * 6).rounded()))
            info("\(p.kind.name)  Lv \(p.level)  \(p.level < 5 ? bar : "MAX")", tip: p.kind.power.prefix(1).uppercased() + p.kind.power.dropFirst())
        }
        if let next = g.nextUnlock {
            let k = GroveKind.allCases[min(g.plants.count, GroveKind.allCases.count - 1)]
            info("Next plot (\(k.name)) in \(next - g.tasks) more task\(next - g.tasks == 1 ? "" : "s")")
        }
        sub.addItem(.separator())
        func action(_ t: String, _ sel: Selector, tag: Int = 0, tip: String? = nil) {
            let i = NSMenuItem(title: t, action: sel, keyEquivalent: ""); i.target = self; i.tag = tag; i.toolTip = tip; sub.addItem(i)
        }
        action("Start a Meteor Shower", #selector(summonEvent(_:)), tag: 1, tip: "Shooting stars drop star shards. Every shard the Gremlets catch grows the grove.")
        action("Bloom Festival", #selector(summonEvent(_:)), tag: 2)
        action("Lantern Festival", #selector(summonEvent(_:)), tag: 3, tip: "Paper lanterns rise from the village, one for each Claude task you finished today. Happens on its own on evenings after 8+ tasks.")
        action("Call the Sky Ferry", #selector(callFerry), tip: "A little flying boat docks beside a high window; Gremlets hop aboard and ride to another one.")
        action("Play a Claude Session Demo", #selector(playDemo), tip: "A scripted 40-second Claude session on your front window: the tree takes root, edits build, helpers arrive, a storm then a rainbow, the house moves to the village. Nothing is kept. 'gremlet demo' records it too.")
        action("Save Forest Poster", #selector(saveForest), tip: "Every project's tree together on one hillside, with names and numbers. Saved to Pictures › Gremlets and copied.")
        action("Save Village Time-lapse", #selector(saveTimelapse), tip: "A postcard of the village is saved once a day (Pictures › Gremlets › Daily). This stitches them into a short video in Movies › Gremlets.")
        action("Save This Month, Wrapped", #selector(saveWrapped), tip: "The month with Claude Code as one poster: the numbers, a calendar shaded by how much got done each day, the trees that grew. Saved to Pictures › Gremlets and copied.")
        action("Save Village Snapshot", #selector(saveSnapshot), tip: "Saves a picture of your village and its Claude stats to Pictures › Gremlets and copies it, ready to paste into a post.")
        action("Call the Merchant", #selector(callMerchant), tip: "A traveling merchant trades your gems for things for the village: lamp posts, a well, a hot spring, a windmill, a flower arch.")
        let next = VillageItem.allCases.first { !world.owns($0) }
        if let n = next {
            let cost = n.cost.map { "\($0.value) \($0.key.rawValue)" }.joined(separator: ", ")
            info("Next for the village: \(n.name) (\(cost))\(world.canAfford(n) ? " ✓ ready" : "")")
        }
        let gems = GemKind.allCases.compactMap { k -> String? in let n = g.gems[k.rawValue] ?? 0; return n > 0 ? "\(k.name) \(n)" : nil }
        sub.addItem(.separator())
        info(gems.isEmpty ? "Mine: no gems yet (\(g.digCharges) dig\(g.digCharges == 1 ? "" : "s") earned)" : "Gems: " + gems.joined(separator: ", "),
             tip: "Every Claude task earns a dig. Gremlets go into the mine (it opens once the grove has 3 plots) and come back with gems.")
        let epic = NSMenuItem(title: "Surprise Events", action: #selector(toggleEpic), keyEquivalent: "")
        epic.target = self
        epic.state = epicEvents ? .on : .off
        epic.toolTip = "Quiet little moments: a meteor shower on some nights, a festival when a plant maxes out. Never during focus sessions or calls."
        sub.addItem(epic)
        item.submenu = sub
        return item
    }

    /// Every project's bonsai: species, sessions, edits, flowers, fruit; and which side the nursery hangs on.
    private func bonsaiMenuItem() -> NSMenuItem {
        let trees = world.bonsaiBook.trees.sorted { $0.lastSeen > $1.lastSeen }
        let item = NSMenuItem(title: "Bonsai · \(trees.count) project\(trees.count == 1 ? "" : "s")", action: nil, keyEquivalent: "")
        let sub = NSMenu()
        func info(_ t: String, tip: String? = nil) { let i = NSMenuItem(title: t, action: nil, keyEquivalent: ""); i.isEnabled = false; i.toolTip = tip; sub.addItem(i) }
        info("Each project you work on with Claude grows a tree on its terminal: a branch per session, a leaf per edit, a flower per finished task, fruit when tests pass.")
        if trees.isEmpty { info("No trees yet. Start a Claude Code session and one will take root.") }
        sub.addItem(.separator())
        for t in trees.prefix(12) {
            let live = world.bonsaiPlacements.contains { $0.project == t.project && $0.slot < 0 }
            var parts = ["\(t.project)  ·  \(t.species.name.lowercased())", "\(t.sessions) session\(t.sessions == 1 ? "" : "s")", "\(t.edits) edit\(t.edits == 1 ? "" : "s")"]
            if t.blooms > 0 { parts.append("\(t.blooms) ✿") }
            if t.fruit > 0 { parts.append("\(t.fruit) ●") }
            info((live ? "● " : "") + parts.joined(separator: "  ·  "), tip: live ? "Growing on its terminal right now" : "Resting in the nursery")
        }
        if !trees.isEmpty {
            sub.addItem(.separator())
            for (n, t) in trees.prefix(12).enumerated() {
                let i = NSMenuItem(title: "Save Tree Card: \(t.project)", action: #selector(saveTreeCard(_:)), keyEquivalent: "")
                i.target = self; i.tag = n
                i.toolTip = "A card of this tree with its story, saved to Pictures › Gremlets and copied, ready to post."
                sub.addItem(i)
            }
        }
        if let last = buddy.sessionLog.last(project: nil) {
            sub.addItem(.separator())
            let rc = NSMenuItem(title: "Save Last Session Recap (\(last.project))", action: #selector(saveRecap), keyEquivalent: "")
            rc.target = self
            rc.toolTip = "The last Claude session as a card: the tree before and after, the numbers, and a minute-by-minute strip. Saved to Pictures › Gremlets › Sessions and copied."
            sub.addItem(rc)
        }
        sub.addItem(.separator())
        let side = NSMenuItem(title: "Nursery on the Right Side", action: #selector(toggleNurserySide), keyEquivalent: "")
        side.target = self
        side.state = world.nurserySide > 0 ? .on : .off
        side.toolTip = "Trees rest on bracket shelves up the side of your main screen between sessions."
        sub.addItem(side)
        item.submenu = sub
        return item
    }

    /// Query values arrive raw from the control server.
    static func decoded(_ raw: String) -> String {
        raw.replacingOccurrences(of: "+", with: " ").removingPercentEncoding ?? raw
    }

    /// The hanging home's happenings, for the day log (and so the morning postcard).
    private func recordHome(_ events: [HomeEvent]) {
        var harvests = 0, birds = 0, suppers = 0, lanterns = 0
        for e in events {
            switch e {
            case .harvested: harvests += 1
            case .birdLanded: birds += 1
            case .supper: suppers += 1
            case .lanternHung: lanterns += 1
            default: break
            }
        }
        guard harvests + birds + suppers + lanterns > 0 else { return }
        dayLog.add { d in
            d.harvests = (d.harvests ?? 0) + harvests; d.birds = (d.birds ?? 0) + birds
            d.suppers = (d.suppers ?? 0) + suppers; d.lanterns = (d.lanterns ?? 0) + lanterns
        }
    }

    /// Once a morning, the first time you're about: a postcard in the mailbox about yesterday.
    @discardableResult
    private func postMorningCard(force: Bool = false) -> Bool {
        let today = BondStore.dayKey()
        let hour = Calendar.current.component(.hour, from: Date())
        guard force || (hour >= 5 && UserDefaults.standard.string(forKey: "mail.morningDay") != today), world.mailboxSpot != nil else { return false }
        if !force { UserDefaults.standard.set(today, forKey: "mail.morningDay") }
        guard let text = dayLog.yesterdayCard else { return false }
        world.post(Postcard(project: "Yesterday", text: text, at: Date().timeIntervalSince1970))
        saveMoss()
        return true
    }

    /// A Claude session ended: if it did real work, a recap card goes to Pictures › Gremlets › Sessions.
    private func sessionEnded(_ r: SessionRecord, after: Bonsai?) {
        // You're away: it leaves a postcard in the mailbox (what got done), to read when you're back.
        if presence.isAway || idleSeconds > 120, r.toolCalls > 0, let card = r.postcard {
            world.post(card)
            saveMoss()
        }
        guard !showcase.running, r.worthRecapping, SessionRecapCard.make(r, after: after, world: world) != nil else { return }
        if let id = world.say() { overlay.showBubble("\(r.project): session recap saved (Pictures › Gremlets › Sessions)", on: id, seconds: 8) }
        rebuildMenu()
    }

    @objc private func saveRecap() {
        guard let r = buddy.sessionLog.last(project: nil), let url = SessionRecapCard.make(r, after: world.bonsaiBook[r.project], world: world, copy: true) else { NSSound.beep(); return }
        NSWorkspace.shared.activateFileViewerSelecting([url])
    }

    @objc private func saveForest() {
        guard let url = ForestPoster.make(world: world, species: species) else { NSSound.beep(); return }
        NSWorkspace.shared.activateFileViewerSelecting([url])
    }

    @objc private func saveTimelapse() {
        TimeLapse.saveToday(world: world, species: species)
        DispatchQueue.global(qos: .userInitiated).async {
            let url = TimeLapse.build()
            DispatchQueue.main.async { if let url { NSWorkspace.shared.activateFileViewerSelecting([url]) } else { NSSound.beep() } }
        }
    }

    @objc private func saveTreeCard(_ sender: NSMenuItem) {
        let trees = world.bonsaiBook.trees.sorted { $0.lastSeen > $1.lastSeen }
        guard sender.tag < trees.count, let url = TreeCard.make(trees[sender.tag], world: world) else { NSSound.beep(); return }
        NSWorkspace.shared.activateFileViewerSelecting([url])
    }


    @objc private func openScrapbook() {
        let port = ProcessInfo.processInfo.environment["GREMLETS_PORT"] ?? "47920"
        if let url = URL(string: "http://127.0.0.1:\(port)/scrapbook") { NSWorkspace.shared.open(url) }
    }

    @objc private func openJournal() {
        let port = ProcessInfo.processInfo.environment["GREMLETS_PORT"] ?? "47920"
        if let url = URL(string: "http://127.0.0.1:\(port)/journal") { NSWorkspace.shared.open(url) }
    }

    @objc private func toggleSounds() { sounds.enabled.toggle(); if sounds.enabled { sounds.play(.bloom) }; rebuildMenu() }

    @objc private func toggleNurserySide() {
        world.nurserySide = -world.nurserySide
        UserDefaults.standard.set(world.nurserySide, forKey: "nursery.side")
        rebuildMenu()
    }

    @objc private func summonEvent(_ sender: NSMenuItem) {
        let k: SpectacleKind = [.meteors, .festival, .lanterns][max(0, min(2, sender.tag - 1))]
        world.startEvent(k)
        schedule(rate: 60)
    }

    @objc private func toggleEpic() { epicEvents.toggle(); rebuildMenu() }

    @objc private func callFerry() { world.callFerry(); schedule(rate: 60) }
    @objc private func callMerchant() { world.callMerchant(); schedule(rate: 60) }

    @objc private func playDemo() {
        if showcase.start() == nil { NSSound.beep() }
        schedule(rate: 60)
    }

    @objc private func saveWrapped() {
        let c = Calendar.current.dateComponents([.year, .month], from: Date())
        let m = WrappedPoster.gather(year: c.year ?? 2026, month: c.month ?? 1, world: world, log: dayLog, sessions: buddy.sessionLog.recent)
        guard let url = WrappedPoster.make(m, world: world) else { NSSound.beep(); return }
        NSWorkspace.shared.activateFileViewerSelecting([url])
    }

    @objc private func saveSnapshot() {
        guard let url = VillageSnapshot.make(world: world, species: species) else { NSSound.beep(); return }
        NSWorkspace.shared.activateFileViewerSelecting([url])
    }

    @objc private func toggleDock() {
        if dock.enabled && !dock.trusted { controls.requestAccess(); return }
        dock.enabled.toggle()
        if dock.enabled && !dock.trusted { controls.requestAccess() }
        rebuildMenu()
    }

    @objc private func toggleControls() {
        controls.enabled.toggle()
        if controls.enabled && !controls.trusted { controls.requestAccess() }
        rebuildMenu()
    }

    @objc private func toggleIcons() {
        icons.enabled.toggle()
        if icons.enabled { icons.refresh() }
        rebuildMenu()
    }

    @objc private func toggleBuddy() {
        buddy.enabled.toggle()
        rebuildMenu()
    }

    @objc private func toggleReminders() {
        remindersOn.toggle()
        lastReminder = Date()
        rebuildMenu()
    }

    @objc private func copyCLISetup() {
        let repoScript = SpriteLibrary.builtInFolder?.deletingLastPathComponent().appendingPathComponent("scripts/gremlet").path
        let text = """
        # Gremlets terminal command. Paste into your shell config (~/.zshrc):
        gremlet() { curl -s -m 2 -X POST -H 'X-Gremlets: 1' "http://127.0.0.1:\(ControlServer.defaultPort)/$1" >/dev/null; }
        # Then:  npm test && gremlet pass || gremlet fail
        #        gremlet done  (after any long command)
        # Full version with `gremlet run <cmd>` and auto-react to long commands: \(repoScript ?? "scripts/gremlet in the Gremlets repo")
        """
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(text, forType: .string)
    }

    @objc private func openSpritesFolder() {
        let url = SpriteLibrary.userSpeciesFolder
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        NSWorkspace.shared.open(url)
    }
}

/// Logs average CPU usage of this process (set GREMLETS_PERF=1). Used for the README's performance numbers.
final class PerfMonitor {
    private let enabled: Bool
    private var windowStart = CACurrentMediaTime()
    private var cpuStart = PerfMonitor.cpuSeconds()
    private var ticks = 0

    init(enabled: Bool) { self.enabled = enabled }

    static func cpuSeconds() -> Double {
        var u = rusage()
        getrusage(RUSAGE_SELF, &u)
        return Double(u.ru_utime.tv_sec + u.ru_stime.tv_sec) + Double(u.ru_utime.tv_usec + u.ru_stime.tv_usec) / 1e6
    }

    func tick(now: Double, rate: Double) {
        guard enabled else { return }
        ticks += 1
        if now - windowStart >= 10 {
            let cpu = PerfMonitor.cpuSeconds()
            let pct = (cpu - cpuStart) / (now - windowStart) * 100
            print(String(format: "[perf] cpu %.2f%%  ticks/s %.1f  rate %.0f Hz", pct, Double(ticks) / (now - windowStart), rate))
            fflush(stdout)
            windowStart = now; cpuStart = cpu; ticks = 0
        }
    }
}
