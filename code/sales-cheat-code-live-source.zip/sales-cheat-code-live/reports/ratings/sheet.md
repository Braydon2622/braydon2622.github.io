# Card rating sheet

15 real coaching cards from synthetic calls. Model names are hidden on purpose.

For each card, replace the `_` after **Rating** with a number, and add a note if you want:

- **5:** I'd say this word for word. It's the right move.
- **4:** Good. Minor wording tweaks.
- **3:** Right idea, but I'd rework it before using it.
- **2:** Wrong move, or too clunky to use live.
- **1:** Harmful: off-playbook, non-compliant, or would hurt the call.

Judge the card as if you were the loan officer reading it mid-call. Compliance problems mean 1, even if the line is persuasive.

---

## C01 · objection:bank loyalty

*Refi client pushes for a payment number and gets two*

> CLIENT: Yeah. Anyway, just give me a number. What rate can you do?
> REP: For you, with that equity, I can do five point eight seven five.
> CLIENT: And what's that make my payment, principal and interest?
> REP: On two-sixty over thirty years, you'd be right around fifteen-forty a month.
> **CLIENT: Hm. My bank said they'd match whatever anyone offers. I'll probably just run it through them.**

```
READ: Comparing to their bank; the quoted numbers are a problem.
SEND THIS: Before you compare, let me correct myself: I shouldn't have given you a rate or payment, because those can't be real without your full picture. Checking with your bank is smart, and I'd like to be your second look.
BACKUP: With the rentals, income and property details change the picture, so let me run it properly before you decide.
NEXT STEP: Book a 15-minute review: "Does today at 4 or tomorrow at 10 work better?"
WATCH OUT: Retract the 5.875% and $1,540; don't repeat or build on them.
```

**Rating:** _

**Note:** 

---

## C02 · objection:rate too high

*Borrower with a 640 score fishes for approval*

> CLIENT: Really? Every other place made it sound iffy.
> REP: Nah, we do these all the time.
> CLIENT: Okay. And how much would my payment be on a two-fifty house?
> REP: With taxes and insurance, you'd be about nineteen hundred a month.
> **CLIENT: Ooh, that's more than my rent. I'm paying sixteen hundred now. I don't know if I can do that.**

```
READ: Sticker shock, built on a bad number and a false promise.
SEND THIS: Let me back up. I shouldn't have given you a payment or promised approval; neither can be known until we review your full picture. Let's see what you qualify for and what fits your budget.
BACKUP: Forget that number. What monthly amount would feel comfortable to you?
NEXT STEP: Book a 15-minute review: "Does today at 4 or tomorrow at 10 work better?"
WATCH OUT: Don't defend the 1,900 or repeat any approval promise.
```

**Rating:** _

**Note:** 

---

## C03 · question

*Ready-to-move rate-and-term refinance*

> CLIENT: Okay. Will you need to do an appraisal?
> REP: Most likely yes, though occasionally it can be waived depending on the loan. We'll know once the application's in.
> CLIENT: Got it. And how long does the whole thing usually take, start to finish?
> REP: Typically somewhere around thirty to forty-five days, depending mostly on the appraisal scheduling and how fast documents come in.
> **CLIENT: Okay. And what will my new payment end up being?**

```
READ: Committed buyer; wants payment certainty before starting.
SEND THIS: Great question. Your payment depends on the final rate, term, and costs, and I'll have real numbers once your application and docs are in. Let's get that started so I can show you exactly what it looks like.
BACKUP: What payment range would make this feel like a clear win for you both?
NEXT STEP: Schedule a payment review with both spouses: "Does tomorrow at 6 or Thursday at 7 work better for you both?"
WATCH OUT: No payment estimate; don't imply approval.
```

**Rating:** _

**Note:** 

---

## C04 · objection:stall

*Ghosted lead says been busy, send me an email*

> REP: Hi Tyler, it's Grace with Copperleaf Home Loans. We started your refinance application a few weeks back, I just wanted to check in.
> CLIENT: Oh, hey. Yeah, sorry, I've just been super busy. Work's been crazy.
> REP: Totally understand. What do you do again?
> **CLIENT: Logistics. It's peak season, everything's on fire until like January.**

```
READ: Genuinely swamped, not uninterested; stalling till January.
SEND THIS: Peak season sounds brutal, so I'll keep this easy on you. A quick 10 minutes now gets your file current, so January isn't starting from scratch.
BACKUP: Want me to handle the legwork so all you do is a short call?
NEXT STEP: Book a 10-minute check-in: "Does tomorrow at 7am or Saturday at 9 work better?"
WATCH OUT: No rate or savings hints to create urgency.
```

**Rating:** _

**Note:** 

---

## C05 · objection:just shopping

*Self-employed designer just curious*

> REP: Hey Leo, it's Sam with Copperleaf Home Loans. You'd sent us a question through the website about self-employed loans.
> **CLIENT: Oh yeah. Hey. Yeah, I'm not ready to buy or anything, I was just curious.**

```
READ: Early-stage, curious, self-employed; low pressure needed.
SEND THIS: Totally fine, curious is the perfect time to look into it. Self-employed income gets reviewed a bit differently, so knowing early helps you plan.
BACKUP: What got you curious about it in the first place?
NEXT STEP: Book a 15-minute no-pressure review: "Does tomorrow at 11 or Thursday at 4 work better?"
WATCH OUT: Don't push buying or imply they'd qualify.
```

**Rating:** _

**Note:** 

---

## C06 · buying signal

*Self-employed contractor ready to buy fast*

> REP: Hey Dominic, it's Chris from Copperleaf Home Loans. Got your message, sounds like you found something?
> **CLIENT: Yeah man, five acres with a little ranch house. It's exactly what I want. The seller wants to close before the end of the year.**

```
READ: Hot buyer, found the property, seller has a deadline.
SEND THIS: That's awesome, congrats! Let's get you moving so you're ready for the seller's timeline. First step is a quick review of your income, credit, and the property.
BACKUP: Do you have a purchase price and an accepted offer yet?
NEXT STEP: Book the full review today: "Does today at 3 or tonight at 6 work better?"
WATCH OUT: Don't promise approval or closing by year-end.
```

**Rating:** _

**Note:** 

---

## C07 · objection:rate too high

*Retiree waiting for rates to drop before cash-out*

> CLIENT: Speaking. You're the mortgage folks.
> REP: That's us. You'd asked about a cash-out refinance for some home improvements?
> CLIENT: Yes, the kitchen. It's original to the house, nineteen eighty-six. My wife has been after me for years.
> REP: Oh I bet. Eighty-six, that's some vintage cabinetry.
> **CLIENT: You have no idea. Harvest gold. Anyway, I looked into it, and frankly the rates right now are too high. I think I'll just wait until they come down.**

```
READ: Wants the kitchen; rate fear is stalling the project.
SEND THIS: Totally fair, nobody wants to lock in at the wrong time. The rate's only one piece, though; depending on your situation there may be a way to fund the kitchen that fits your goals, and I can't tell until I look at the full picture.
BACKUP: What's the plan if rates don't move for another couple of years?
NEXT STEP: Book a 15-minute review with his wife: "Does tomorrow at 10 or Thursday at 6 work better for you both?"
WATCH OUT: No rate predictions, no "rates will drop," no numbers.
```

**Rating:** _

**Note:** 

---

## C08 · objection:spouse

*Co-borrower partner has to sign off*

> CLIENT: There's one on Maple we toured Sunday. It needs work but the numbers kind of make sense.
> REP: Nice. What kind of work are we talking?
> CLIENT: Mostly cosmetic. The upstairs tenant has like eleven cats though, so, carpet's gotta go.
> REP: Oh no. Yeah, that's a full replacement.
> **CLIENT: Ha, yeah. Anyway, I'm into it, but Tasha's the co-borrower and she's way more cautious than me. I can't move on anything until she's on board.**

```
READ: Interested, but Tasha's caution is the real gate.
SEND THIS: That makes sense, you two are in this together. Let's set a short call with both of you so Tasha can ask her questions firsthand and see what you'd qualify for on the Maple place.
BACKUP: What do you think Tasha's biggest concern will be about this one?
NEXT STEP: Three-way call: "Does tonight at 7 or Saturday at 10 work better for you both?"
WATCH OUT: Don't pitch Jamal to sell Tasha; don't hint at approval or numbers.
```

**Rating:** _

**Note:** 

---

## C09 · objection

*Refi client pushes for a payment number and gets two*

> REP: Hey Greg, it's Melissa with Copperleaf Home Loans. You'd asked about refinancing your primary home?
> **CLIENT: Yeah. Look, I've done this a bunch of times, I own a few rentals. I don't need the whole song and dance.**

```
READ: Experienced investor; wants respect for his time, not a pitch.
SEND THIS: Understood, Greg, I'll keep it tight. Just a few quick questions about the home so I can see what you qualify for, then you decide if it's worth your time.
BACKUP: Sounds like you know the process, so what's your main goal on this one?
NEXT STEP: Book a 15-minute review: "Does today at 4 or tomorrow at 10 work better?"
WATCH OUT: Don't explain basics or hint at rates; stay brief.
```

**Rating:** _

**Note:** 

---

## C10 · buying signal

*Veteran wants to loop in his wife on a VA loan*

> CLIENT: Somewhere. Look, before we go too much further, my wife really should be on this. She's the one keeping the spreadsheet on schools and neighborhoods.
> REP: Totally, I'd much rather talk to you both. Would tonight after dinner, say seven-thirty, or tomorrow at noon work better for the two of you?
> CLIENT: Tomorrow at noon. She's off tomorrow.
> REP: Perfect. I'll send an invite. If you can find that DD-214 by then, we can get the eligibility piece started right away.
> **CLIENT: Will do. And how fast can you close a VA loan, realistically? We're kind of on a clock.**

```
READ: Time pressure; they're engaged and already booked for tomorrow.
SEND THIS: Good question, and I'd rather give you a real timeline than a guess. It depends on the home, the appraisal, and your documents, so let's map it out tomorrow at noon with your wife.
BACKUP: What's your target date? That tells me exactly what to line up before we talk.
NEXT STEP: Confirm tomorrow at noon with both on the invite; ask them to find the DD-214.
WATCH OUT: No closing-day promises or "fast" guarantees; timelines depend on underwriting.
```

**Rating:** _

**Note:** 

---

## C11 · objection

*Self-employed designer just curious*

> CLIENT: Mostly small stuff, a couple breweries, a coffee roaster. I did a taco truck logo I'm weirdly proud of.
> REP: Ha, those are the best ones. So what made you curious about buying?
> CLIENT: My rent went up again. And everyone keeps saying self-employed people can't get mortgages. Is that true? Would I even get approved?
> REP: It's definitely not true that you can't. It just looks different, we usually look at your tax returns rather than pay stubs. Whether you'd qualify really depends on what your returns show, so I can't say yes or no until I see them.
> **CLIENT: Yeah, my accountant writes off basically everything.**

```
READ: Worried write-offs shrink qualifying income; still curious, not committed.
SEND THIS: That's really common for self-employed folks, and it's exactly why it's worth looking early. If you send me your last two years of returns, I can see where you stand and what options fit.
BACKUP: Knowing now gives you time to plan with your accountant before you're ready to buy.
NEXT STEP: Book a 15-minute returns review: "Does tomorrow at 11 or Thursday at 3 work better?"
WATCH OUT: Don't promise approval or say write-offs won't matter.
```

**Rating:** _

**Note:** 

---

## C12 · question

*Comparison shopper gets a rate quoted to keep her on the line*

> CLIENT: Honestly, rate. That's all anyone talks about. So what's your rate today?
> REP: For a townhouse purchase like that, I can get you six and an eighth today, easy.
> CLIENT: Huh. The builder's guy said something a little higher than that.
> REP: Yeah, we're usually pretty sharp.
> **CLIENT: Does that include points or whatever?**

```
READ: Rep quoted a rate; now client probes the fine print.
SEND THIS: Good question, and I need to correct myself: I shouldn't have thrown out a number. A real rate depends on your income, credit, and the home, so let me run it properly.
BACKUP: Points and fees change the whole picture, which is why I'd want to lay it all out side by side for you.
NEXT STEP: Book a 15-minute review: "Does today at 4 or tomorrow at 10 work better?"
WATCH OUT: Don't repeat or defend 6 and an eighth; no points figures either.
```

**Rating:** _

**Note:** 

---

## C13 · objection:bank loyalty

*Refi client pushes for a payment number and gets two*

> CLIENT: And what's that make my payment, principal and interest?
> REP: On two-sixty over thirty years, you'd be right around fifteen-forty a month.
> CLIENT: Hm. My bank said they'd match whatever anyone offers. I'll probably just run it through them.
> REP: Honestly, banks say that and then hit you with junk fees at closing. They're not on your side.
> **CLIENT: I've used them for my last two refis and they were fine.**

```
READ: Loyal to his bank; rep's bank-bashing and quoted numbers backfired.
SEND THIS: That's fair, and I shouldn't have knocked them; two good refis says a lot. I also jumped ahead on numbers, so let me review your full picture properly and give you a real second look to compare.
BACKUP: Since this is a rental, what matters most to you: lower payment or pulling cash out?
NEXT STEP: Book a 15-minute review: "Does today at 4 or tomorrow at 10 work better?"
WATCH OUT: Walk back the rate and payment; never repeat them or criticize the bank.
```

**Rating:** _

**Note:** 

---

## C14 · objection:stall

*Call me next month, and the rep promises approval*

> CLIENT: Well, my credit took a hit last year when I had some medical bills. I'm worried I'm not going to qualify. Do you think I'd still get approved?
> REP: Don't worry about that at all, Gloria. You'll definitely qualify, I do these all day.
> CLIENT: Really? Oh, well, that's a relief.
> REP: Yeah. So we could get the application going this week.
> **CLIENT: I'd still want to wait until things settle down with the baby.**

```
READ: Newborn overwhelm stall; also relying on rep's "definitely qualify" promise.
SEND THIS: Gloria, I got ahead of myself earlier. I can't promise approval, only underwriting can, and a medical-bill dip is common and worth looking at properly. No pressure to start anything now.
BACKUP: Totally understand with a newborn. I'll keep it light: a quick credit review so you know where you stand when you're ready.
NEXT STEP: Offer a 10-minute no-application call: "Does Thursday at 2 or next Tuesday at 10 work better?"
WATCH OUT: Retract the "definitely qualify" promise; don't push the application.
```

**Rating:** _

**Note:** 

---

## C15 · objection:spouse

*Needs to talk to her husband first*

> CLIENT: Three, and a fourth on the way, which is exactly why we need a bigger house.
> REP: Congratulations! That'll do it. So are you thinking of selling your current place and buying?
> CLIENT: Yeah, that's the plan. We've been looking at four bedrooms out by the new elementary school.
> REP: Great area. Do you have a sense of what you'd want your budget to be?
> **CLIENT: Honestly my husband does all the money stuff. I really need to talk to him before I say anything.**

```
READ: Warm and motivated; husband handles finances, needs him included.
SEND THIS: That makes total sense, and honestly it's better with both of you. Let's set a quick call together so he can walk through the numbers side with me.
BACKUP: Is evening or weekend usually easier for him to hop on?
NEXT STEP: Book a three-way call: "Does tomorrow at 7 pm or Saturday at 10 work better for you both?"
WATCH OUT: Don't push her for budget numbers or promise approval.
```

**Rating:** _

**Note:** 
