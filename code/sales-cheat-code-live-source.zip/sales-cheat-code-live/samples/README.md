# Sample calls

SYNTHETIC role-play transcripts for trying the call-review app (`npm run app`). The personal details in them are fake and exist only to show the redaction working. Regenerate with `npx tsx scripts/make-samples.ts`.

`roleplay-spouse-call.m4a` is a SYNTHETIC 54-second recording made with two macOS text-to-speech voices (no real people). Drag it into the app to try audio upload. It includes a rate quote and a spouse objection. It needs `DEEPGRAM_API_KEY`.
